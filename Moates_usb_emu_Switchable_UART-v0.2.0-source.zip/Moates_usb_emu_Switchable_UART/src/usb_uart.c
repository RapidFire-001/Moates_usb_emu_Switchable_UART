// Copyright (C) 2026
//
// MIT License
//
// One ROM USB system plugin - UART <-> CDC bridge (Fire 32 A, RP2350B).
// HW UART1 on GPIO38 (TX=SEL_C) / GPIO39 (RX=SEL_D); Ostrich serving owns
// PIO0-2 (locked at init) so the bridge uses the HW UART. Baud per UART_MODE
// (tusb_config.h): ALDL=8192 split-polarity, HTS=38400 TTL, DISABLED=hide.
// Register values are from the RP2350 datasheet.

#include "tusb.h"
#include "pico.h"        // pico-sdkless: reset_block(), unreset_block_wait()
#include <stdint.h>
#include <stdbool.h>

// RP2350 UART1 register definitions
#define UART1_BASE                 0x40078000u   // RP2350 datasheet
                                                // (0x40070000 is UART0, 0x40078000 is UART1)
#define UART_DR_OFFSET             0x00u   // data register (read = RX, write = TX)
#define UART_RSR_OFFSET            0x04u   // receive status (read-only)
#define UART_FR_OFFSET             0x18u   // flag register
#define UART_IBRD_OFFSET           0x24u   // integer baud rate divisor
#define UART_FBRD_OFFSET           0x28u   // fractional baud rate divisor
#define UART_LCR_H_OFFSET          0x2Cu   // line control register
#define UART_CR_OFFSET              0x30u   // control register
#define UART_IFLS_OFFSET            0x34u   // interrupt FIFO level select
#define UART_IMSC_OFFSET            0x38u   // interrupt mask
#define UART_ICR_OFFSET             0x44u   // interrupt clear register

#define UART1_DR     (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_DR_OFFSET))
#define UART1_RSR    (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_RSR_OFFSET))
#define UART1_FR     (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_FR_OFFSET))
#define UART1_IBRD   (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_IBRD_OFFSET))
#define UART1_FBRD   (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_FBRD_OFFSET))
#define UART1_LCR_H  (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_LCR_H_OFFSET))
#define UART1_CR     (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_CR_OFFSET))
#define UART1_IFLS   (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_IFLS_OFFSET))
#define UART1_IMSC   (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_IMSC_OFFSET))
#define UART1_ICR    (*(volatile uint32_t *)((uintptr_t)UART1_BASE + UART_ICR_OFFSET))

// Flag register (UART_FR) bits
#define UART_FR_TXFF   (1u << 5)   // TX FIFO full
#define UART_FR_RXFE   (1u << 4)   // RX FIFO empty
#define UART_FR_TXFE   (1u << 7)   // TX FIFO empty
#define UART_FR_RXFF   (1u << 6)   // RX FIFO full (informational)
#define UART_FR_BUSY   (1u << 3)   // UART busy transmitting

// Control register (UART_CR) bits
#define UART_CR_UARTEN (1u << 0)
#define UART_CR_TXE    (1u << 8)
#define UART_CR_RXE    (1u << 9)

// Line control register (UART_LCR_H) bits
#define UART_LCR_H_FEN  (1u << 4)   // enable FIFOs
#define UART_LCR_H_WLEN_8 (0x3u << 5)  // 8-bit word length

// GPIO and pad control (for TX/RX pin setup)
#define IO_BANK0_BASE             0x40028000u
#define PADS_BANK0_BASE           0x40038000u
#define GPIO_CTRL_OFFSET          0x004u
#define GPIO_CTRL_SPACING         0x008u
#define PAD_OFFSET_START          0x004u
#define PAD_SPACING               0x004u   // RP2350: PADS_BANK0 is 4 bytes per GPIO
                                          // (one ctrl register per GPIO at PADS_BANK0+0x04+pin*4).
                                          // NOT 0x008 — that is GPIO_SPACING (because GPIO has
                                          // separate status+ctrl registers).
// UART1 TX/RX FUNCSEL = 0x0b (RP2350). (0x03 on these pins is I2C1, not UART1.)
#define GPIO_CTRL_FUNC_UART       0x0bu
#define PAD_OUTPUT_DIS_BIT        (1u << 7)   // RP2350 PADS_BANK0: OD bit
                                               // (NOT bit 5 — bit 5 is part of the DRIVE field 4-5)
#define PAD_IE_BIT                (1u << 6)   // RP2350 PADS_BANK0: IE bit
                                               // (NOT bit 4 — bit 4 is the start of the DRIVE field)
#define PAD_ISO_BIT               (1u << 8)   // RP2350: PADS_BANK0_GPIOx_ISO_BITS = bit 8

// GPIO INOVER/OUTOVER pad override can't switch fast enough at 8192 baud on
// this silicon (alternating bits); inversion is done in firmware (uart_xform_*).

#define GPIO_CTRL_REG(pin) \
    (*(volatile uint32_t *)((uintptr_t)IO_BANK0_BASE + GPIO_CTRL_OFFSET + (pin) * GPIO_CTRL_SPACING))
#define GPIO_PAD_REG(pin) \
    (*(volatile uint32_t *)((uintptr_t)PADS_BANK0_BASE + PAD_OFFSET_START + (pin) * PAD_SPACING))

// UART1 clock and reset
//
// UART1 clock/reset. No CLK_UART1_CTRL on RP2350 — enable parent clk_peri
// (CLOCKS_BASE+0x48, ENABLE bit 11). Reset in RESETS block, bit 27.
#define CLOCK_PERI_CTRL           (*(volatile uint32_t *)0x40010048u)
#define CLOCK_PERI_CTRL_ENABLE    (1u << 11)
#define RESETS_RESET_UART1_BITS   (1u << 27)   // RESETS_RESET_UART1_BITS = 0x08000000
                                                // (NOT bit 23 — that's TIMER0 = 0x00800000)

// Configuration: pin assignments and clock-divisor for each UART mode

// UART GPIO pins (Fire 32 A default): FUNCSEL 0x0b maps GPIO38->TX,
// GPIO39->RX. Override with UART_TX_PIN=N / UART_RX_PIN=N at build.
#ifndef UART_TX_PIN
#define UART_TX_PIN    38u   // Fire 32 A default: SEL_C (F11 = UART1 TX)
#endif
#ifndef UART_RX_PIN
#define UART_RX_PIN    39u   // Fire 32 A default: SEL_D (F11 = UART1 RX)
#endif

// UART wire config, selected by UART_MODE (in tusb_config.h so descriptors
// react too):
//   NORMAL   : non-inverted 38400 8N1 (default)
//   ALDL_808 : Delco 808 post-MAX232 tap, split idle polarity — TX idles HIGH
//              (not inverted), RX idles LOW (inverted). 8192 baud.
//   HTS      : Honda datalogging, 38400 8N1 TTL
//   DISABLED : 2nd CDC hidden, bridge not built
// Inversion is per-direction in firmware (uart_xform_tx/rx XOR the byte, not
// the pad). UART_CLKDIV_INT/FRAC = clk_peri/(16*baud), clk_peri=150MHz.
#if (UART_MODE == UART_MODE_ALDL_808)
  #define UART_INVERT_DATA    0
  #ifndef UART_INVERT_TX
  #define UART_INVERT_TX      0          // Default: straight-through non-inverted.
  #endif
  #ifndef UART_INVERT_RX
  #define UART_INVERT_RX      0          // Default: straight-through non-inverted.
                                         // Build with UART_INVERT_RX=1 for Delco 808
                                         // hardware (MAX232 inverts the line).
  #endif
  #define UART_BAUD           8192u
  #define UART_IBRD           1144u      // 150e6 / (16 * 8192)  = 1144.04
  #define UART_FBRD           3u         // 0.04 * 64             =  2.6 -> 3
#elif (UART_MODE == UART_MODE_HTS)
  #define UART_INVERT_DATA    0
  #ifndef UART_INVERT_TX
  #define UART_INVERT_TX      0
  #endif
  #ifndef UART_INVERT_RX
  #define UART_INVERT_RX      0
  #endif
  #define UART_BAUD           38400u
  #define UART_IBRD           244u       // 150e6 / (16 * 38400) = 244.14
  #define UART_FBRD           9u         // 0.14 * 64             =  9.0
#else
  #define UART_INVERT_DATA    0
  #ifndef UART_INVERT_TX
  #define UART_INVERT_TX      0
  #endif
  #ifndef UART_INVERT_RX
  #define UART_INVERT_RX      0
  #endif
  #define UART_BAUD           38400u
  #define UART_IBRD           244u       // 150e6 / (16 * 38400) = 244.14
  #define UART_FBRD           9u         // 0.14 * 64             =  9.0
#endif

#if UART_CDC_PRESENT && (UART_MODE != UART_MODE_DT)   // ===== bridge built only when the 2nd CDC is present and not DT mode =====

#if UART_GPIO_DEBUG
// Diagnostic: print GPIO26_CTRL / GPIO27_CTRL readback to CDC0 (Ostrich
// port). The host opens COM16 *after* enumeration, so any "INIT" print
// at boot is invisible. Only emit AFTER the host has mounted the CDC.
// Format: "TASK: GPIO26=0x12345678 GPIO27=0x12345678\r\n"
// snprintf is not available (plugin links with -nostdlib), so we build
// the line manually.
static void u8_to_hex(uint8_t b, char *out) {
    static const char hex[] = "0123456789ABCDEF";
    out[0] = hex[(b >> 4) & 0xF];
    out[1] = hex[b & 0xF];
}
static void u32_to_hex8(uint32_t v, char *out) {
    u8_to_hex((uint8_t)(v >> 24), out);
    u8_to_hex((uint8_t)(v >> 16), out + 2);
    u8_to_hex((uint8_t)(v >> 8), out + 4);
    u8_to_hex((uint8_t)v, out + 6);
}
static void print_gpio_regs(const char *prefix) {
    // COM port does not exist until USB enumeration completes, so a
    // print at boot is invisible. Only emit after the host has
    // connected to CDC0 and the line state is ready (DTR/RTS set).
    if (!tud_cdc_n_connected(0)) return;
    if (!tud_cdc_n_ready(0)) return;
    uint32_t g26 = GPIO_CTRL_REG(UART_TX_PIN);
    uint32_t g27 = GPIO_CTRL_REG(UART_RX_PIN);
    char buf[64];
    int i = 0;
    while (prefix[i] && i < 8) { buf[i] = prefix[i]; i++; }
    buf[i++] = ':';
    buf[i++] = ' ';
    static const char tag[] = "GPIO26=0x";
    for (int j = 0; tag[j]; j++) buf[i++] = tag[j];
    u32_to_hex8(g26, &buf[i]); i += 8;
    buf[i++] = ' ';
    static const char tag2[] = "GPIO27=0x";
    for (int j = 0; tag2[j]; j++) buf[i++] = tag2[j];
    u32_to_hex8(g27, &buf[i]); i += 8;
    buf[i++] = '\r';
    buf[i++] = '\n';
    // Attempt the write. If the Ostrich TX FIFO is momentarily full
    // we just drop this sample and try again on the next task tick.
    uint32_t avail = tud_cdc_n_write_available(0);
    if (avail < (uint32_t)i) return;
    tud_cdc_n_write(0, buf, (uint32_t)i);
    tud_cdc_n_write_flush(0);
}
#endif

// Per-byte data inversion (XOR 0xFF) for split-polarity taps (Delco 808 via
// MAX232), direction-aware. Only data bits inverted, framing standard. Done in
// firmware because the GPIO override is too slow at 8192 baud on this silicon.
static inline uint8_t uart_xform_tx(uint8_t b) {
#if UART_INVERT_TX
    return (uint8_t)~b;
#else
    return b;
#endif
}
static inline uint8_t uart_xform_rx(uint8_t b) {
#if UART_INVERT_RX
    return (uint8_t)~b;
#else
    return b;
#endif
}

// Init
void usb_uart_init(void) {
    // Enable UART1 clock. RP2350 has a separate clock gate for each UART.
    CLOCK_PERI_CTRL |= CLOCK_PERI_CTRL_ENABLE;

    // Take UART1 out of reset (idempotent — safe even if already unreset).
    reset_block(RESETS_RESET_UART1_BITS);
    unreset_block_wait(RESETS_RESET_UART1_BITS);

    // Disable UART1 while we configure it.
    UART1_CR = 0;

    // Clear any pending interrupts.
    UART1_ICR = 0x7FFu;

    // Configure baud rate (integer + fractional divisor for clk_peri / 16).
    UART1_IBRD = UART_IBRD;
    UART1_FBRD = UART_FBRD;

    // 8N1, FIFO enabled. Write LCR_H in one shot (it shares an address
    // with the baud-rate latch — writing IBRD/FBRD/LCR_H in any order is OK
    // as long as the final LCR_H write commits the baud latch).
    UART1_LCR_H = UART_LCR_H_FEN | UART_LCR_H_WLEN_8;

    // Enable UART, TX, RX. (TXE + RXE + UARTEN.)
    UART1_CR = UART_CR_UARTEN | UART_CR_TXE | UART_CR_RXE;

    // Route GPIO26/27 to the UART function. The GPIO pad override
    // (OUTOVER / INOVER) is NOT used — on this RP2350 silicon the
    // override mux can't switch fast enough at 8192 baud for
    // alternating bit patterns, so the per-byte XOR happens in
    // uart_xform_tx / uart_xform_rx in usb_uart_task() instead.
    GPIO_CTRL_REG(UART_TX_PIN) = GPIO_CTRL_FUNC_UART;
    GPIO_CTRL_REG(UART_RX_PIN) = GPIO_CTRL_FUNC_UART;

    // Pad: TX needs output enabled (clear OD), clear ISO, set drive 8mA + slew fast.
    //      RX needs input enabled (set IE), output disabled (set OD), clear ISO.
    // RP2350 pad bits: SLEWFAST=0, PDE=2, PUE=3, DRIVE=4-5, IE=6, OD=7, ISO=8.
    // Use plain assignment (NOT read-modify-write) because the OneROM firmware
    // (or boot ROM) leaves stray PDE/PUE bits set on GPIO 26/27, and an
    // OR-write preserves them. Direct assignment clears them.
    //
    // When inversion is active, drop SLEWFAST: the GPIO override + fast
    // edges produce ringing/garbled bits at 8192 baud for alternating
    // patterns (0x55, 0xAA). Slower edges (SLEWFAST=0) give the UART
    // a clean signal to sample.
#if UART_INVERT_TX || UART_INVERT_RX
    GPIO_PAD_REG(UART_TX_PIN) = (2u << 4)             // DRIVE = 8mA, no SLEWFAST
                                 | PAD_IE_BIT;        // IE (loopback readback)
    GPIO_PAD_REG(UART_RX_PIN) = (2u << 4)             // DRIVE = 8mA, no SLEWFAST
                                 | PAD_IE_BIT         // IE
                                 | PAD_OUTPUT_DIS_BIT; // OD (RX is input)
#else
    GPIO_PAD_REG(UART_TX_PIN) = (1u << 0)              // SLEWFAST
                                 | (2u << 4)             // DRIVE = 8mA
                                 | PAD_IE_BIT;           // IE (loopback readback)
    GPIO_PAD_REG(UART_RX_PIN) = (1u << 0)              // SLEWFAST
                                 | (2u << 4)             // DRIVE = 8mA
                                 | PAD_IE_BIT            // IE
                                 | PAD_OUTPUT_DIS_BIT;   // OD (RX is input)
#endif

    // No INIT print here: the host COM port does not exist at boot
    // (USB has not enumerated yet), so any print would be invisible.
    // The periodic print in usb_uart_task() handles diagnostics.
}

// Bridge task — call once per main loop after tud_task()
//
// Drains CDC1 (host) into UART1 TX, drains UART1 RX into CDC1. Bounded per
// pass to keep the task snappy. The UART1 FIFO is 32 entries deep; we
// service at most 32 bytes per direction per call.

// The UART bridge uses the SECOND CDC interface (index 1, "One ROM CDC
// Trace"). CDC interface 0 ("One ROM Serial") is reserved for the Ostrich-
// compatible serial channel and must NOT be touched here.
#define UART_CDC_ITF  1

#ifndef UART_CDC_SELFTEST
#define UART_CDC_SELFTEST 0
#endif

void usb_uart_task(void) {
#if UART_CDC_SELFTEST
    // DIAGNOSTIC (build with -DUART_CDC_SELFTEST=1): pure CDC1 -> CDC1 echo,
    // bypassing the UART completely. No jumper needed. If characters typed
    // into the "CDC Trace" port echo back, then USB enumeration, the CDC
    // instance-1 in/out path, and task pumping are ALL good -> any
    // loopback failure is in the UART path.
    {
        bool wrote = false;
        while (tud_cdc_n_available(UART_CDC_ITF)) {
            if (!tud_cdc_n_write_available(UART_CDC_ITF)) break;
            tud_cdc_n_write_char(UART_CDC_ITF, tud_cdc_n_read_char(UART_CDC_ITF));
            wrote = true;
        }
        if (wrote) tud_cdc_n_write_flush(UART_CDC_ITF);
        return;
    }
#endif

#if UART_GPIO_DEBUG
    // Periodic GPIO CTRL readback to CDC0. Watches for the OneROM firmware
    // (or anything else) clobbering the INOVER/OUTOVER bits at runtime.
    // Only prints on CHANGE so the line is readable in Putty (no spam).
    {
        static uint32_t call_count = 0;
        if (++call_count >= 1000u) {
            call_count = 0;
            static uint32_t last_g26 = 0xFFFFFFFFu;
            static uint32_t last_g27 = 0xFFFFFFFFu;
            static bool first_print = true;
            uint32_t g26 = GPIO_CTRL_REG(UART_TX_PIN);
            uint32_t g27 = GPIO_CTRL_REG(UART_RX_PIN);
            if (first_print || g26 != last_g26 || g27 != last_g27) {
                first_print = false;
                last_g26 = g26;
                last_g27 = g27;
                print_gpio_regs("TASK");
            }
        }
    }
#endif

    // PC -> ECU: drain CDC1 into UART1 TX FIFO.
    {
        while (tud_cdc_n_available(UART_CDC_ITF)) {
            if (UART1_FR & UART_FR_TXFF) break;
            UART1_DR = (uint32_t)uart_xform_tx((uint8_t)tud_cdc_n_read_char(UART_CDC_ITF));
        }
    }

    // ECU -> PC: drain UART1 RX FIFO into CDC1. Fix: read UART1_DR ONCE
    // per iteration (previous code had a wasted first read).
    bool wrote = false;
    for (int n = 0; n < 32; n++) {
        if (UART1_FR & UART_FR_RXFE) break;
        if (!tud_cdc_n_write_available(UART_CDC_ITF)) break;
        tud_cdc_n_write_char(UART_CDC_ITF,
            uart_xform_rx((uint8_t)(UART1_DR & 0xFFu)));
        wrote = true;
    }

    // Flush CDC1 on write, or periodically as a fallback.
    static uint32_t since_flush = 0;
    if (wrote || ++since_flush >= 100u) {
        tud_cdc_n_write_flush(UART_CDC_ITF);
        since_flush = 0;
    }

    // Re-apply pad config on every call. The OneROM firmware's PIO init
    // can clobber the pad (e.g. setting ISO on GPIO27 which electrically
    // disconnects the pad). Re-applying is cheap (2 stores) and keeps the
    // bridge running even if the host firmware is misbehaving.
    // When inversion is active, drop SLEWFAST (see init for rationale).
#if UART_INVERT_TX || UART_INVERT_RX
    GPIO_PAD_REG(UART_TX_PIN) = (2u << 4)             // DRIVE = 8mA, no SLEWFAST
                                 | PAD_IE_BIT;
    GPIO_PAD_REG(UART_RX_PIN) = (2u << 4)             // DRIVE = 8mA, no SLEWFAST
                                 | PAD_IE_BIT
                                 | PAD_OUTPUT_DIS_BIT;
#else
    GPIO_PAD_REG(UART_TX_PIN) = (1u << 0)              // SLEWFAST
                                 | (2u << 4)             // DRIVE = 8mA
                                 | PAD_IE_BIT;           // IE (loopback readback)
    GPIO_PAD_REG(UART_RX_PIN) = (1u << 0)              // SLEWFAST
                                 | (2u << 4)             // DRIVE = 8mA
                                 | PAD_IE_BIT            // IE
                                 | PAD_OUTPUT_DIS_BIT;   // OD (RX is input)
#endif
}

#else  // !UART_CDC_PRESENT || UART_MODE_DT  ============================================
// Second CDC hidden (UART_MODE_DISABLED) or Data Tracing mode: the UART bridge
// is not built. Provide no-op entry points so usb_main.c can call them unconditionally.
void usb_uart_init(void) {}
void usb_uart_task(void) {}
#endif // UART_CDC_PRESENT && UART_MODE_DT
