// Copyright (C) 2026 — MIT License
//
// One ROM USB system plugin: Ostrich-compatible serial on CDC interface 0.
// Presents "One ROM Serial" (CDC 0) as an Ostrich device so TunerPro RT 5
// and Z-mode hosts can read/write the live ROM image.
//
//  REVISION J — Ostrich Z protocol support
//  PROTOCOL_MODE build switch (mutually exclusive at compile time):
//    PROTO_OSTRICH   (default): Rev H behaviour, bare Ostrich on CDC 0.
//    PROTO_OSTRICH_Z          : bare Ostrich + 'Z'-prefixed streaming,
//                               B R/E/S bank tree, S/BB/BRR handling.
//    Build Z variant: make PROTOCOL_MODE=PROTO_OSTRICH_Z
//
//  Build knobs (defaults = released config):
//    PROTOCOL_MODE=PROTO_OSTRICH    mode select
//    OST_CDC_RX_FS=N                FS CDC RX FIFO bytes (default 64)
//    OST_PERSIST_ON_IDLE=0          disable idle auto-commit (default on)
//    OST_TRACE_RX                   mirror Ostrich RX to Trace CDC (off)
//    UART_MODE=2                    drop Trace CDC (frees RAM/endpoints)
//    UART_TX_PIN=N / UART_RX_PIN=N  override default GPIO (38/39)
//
//  Invariants:
//    - All parsing runs in usb_ostrich_task() (main loop), never in the
//      USB IRQ (tud_cdc_rx_cb): a bank write in IRQ can bkpt-assert.
//    - Every access is clamped to app_get_active_rom_size(): OOB write
//      dropped, OOB read returns 0xFF. Never faults.
//  WIRE FORMAT
//  Address big-endian absolute: addr = (addrhi<<8)|addrlo. Reads stateless
//  (no auto-increment). count is a BYTE count (0 => 256).
//
//  QUERY (2-byte opcode, immediate raw reply):
//    'VV' version -> 14 07 4F   'NS' serial -> 00 04 20 04 20 04 20 04 20 90
//    'FF' info -> 04 01         'CM' status -> 'O'(4F)   'BB' bank -> 00
//  BLOCK:
//    'R' count addrhi addrlo cksum         -> stream count bytes (+trailer)
//    'W' count addrhi addrlo data... cksum -> reply 'O'(4F)
//    W checksum TRAILS data (3-byte header); R checksum is the 4th header byte.
//
//  Z-MODE (PROTO_OSTRICH_Z) adds, alongside the bare commands above:
//    'BB' silent;  'BRR' -> 0x00 (swallow cksum);  'S' -> swallow param+cksum.
//    B R/E/S n -> set/read bank, reply 'O'.
//    'Z' then:
//      'W' count MMSB MSB <count*256 bytes> -> stream to (MMSB<<16)|(MSB<<8),
//                                              single 'O' at end.
//      'R' count MMSB MSB cksum             -> count*256 bytes + 1 cksum.
//    Between Z-W blocks the parser sits in OST_HTZ_AWAIT_Z, ignoring every
//    byte except the next 'Z' (gap bytes alias command letters and desync
//    otherwise); falls back to IDLE after OST_RAW_IDLE_MS.

#include "usb_ostrich.h"
#include "tusb.h"
#include <string.h>
#ifdef OST_DT
#include "usb_dt.h"
#endif

// Ownership marker in .rodata (flash): never referenced, zero RAM/runtime cost
// (`used` forces emission). Visible via `strings` on the .bin.
__attribute__((used))
static const char ost_copyright[] = "Copyright 2026 TXRX";

//  CONFIG

// Wire framing. OST_ADDR_LITTLE_ENDIAN / OST_COUNT_IS_BLOCKS are bench A/B
// flags; leave at 0 (big-endian addr, byte count). W header is 3 bytes (cksum
// trails data), R is 4 (cksum in header). An edit here silently desyncs framing.
#define OST_ADDR_LITTLE_ENDIAN   0
#define OST_COUNT_IS_BLOCKS      0
#define OST_BLOCK_SIZE           256u        // RX/TX chunk + page granularity
#define OST_READ_TRAILER         1           // append 8-bit sum of returned data
#define OST_WRITE_REPLY          0x4F        // 'O' = OK
#define OST_BANK_WINDOW_SIZE     8192u
#define OST_BANK_AFFECTS_OFFSET  1
#define OST_RW_PARAM_LEN         4u          // R header: count, addrhi, addrlo, cksum
#define OST_W_HDR_LEN            3u          // W header: count, addrhi, addrlo
#define OST_SEND_MAX_STALLS      1000u

_Static_assert(OST_W_HDR_LEN == 3u,
               "W header must be exactly count, addrhi, addrlo");
_Static_assert(OST_RW_PARAM_LEN == OST_W_HDR_LEN + 1u,
               "R header must be the W header plus one trailing checksum byte");
_Static_assert(OST_BLOCK_SIZE == 256u,
               "read/write chunking and page granularity assume 256-byte blocks");

// Served ROM size. 0 = follow configured chip via app_get_active_rom_size()
// (27C010->131072, 27C020->262144, 27C040->524288). Non-zero pins it regardless
// of config. OOB read -> 0xFF, OOB write dropped.
#define OST_FORCE_ROM_SIZE       131072u  // pin to 27C010 (128 KB) window

// Flash persistence: debounced auto-commit (default on). Writes land in the
// volatile live image; after OST_PERSIST_IDLE_MS idle they are written back to
// the preloaded flash slot (bootrom primitives) so they survive power cycle.
// Commit is erase+program with interrupts off, so it fires only when the host
// is idle. =0 disables. Per-sector drain: see ost_persist_commit.
#ifndef OST_PERSIST_ON_IDLE
#define OST_PERSIST_ON_IDLE      1
#endif
#ifndef OST_PERSIST_IDLE_MS
#define OST_PERSIST_IDLE_MS      1500u   // commit this long after the last write
#endif

// Raw-mode idle timeout: exit raw mode after this many ms with no raw bytes
// so post-upload queries (FF, VV, ...) parse again. board_millis()-based.
#ifndef OST_RAW_IDLE_MS
#define OST_RAW_IDLE_MS          500u
#endif

// First-W diagnostic + write-log + post-write capture (default OFF; production
// 'FF' reply stays 04 01). -DOST_DBG_FIRSTW=1 appends counters to the 'FF'
// reply; no per-byte CDC write, so stream timing is unperturbed.
//
// Extended 'F''F' reply when enabled:
//     04 01 AA 55  <cnt> <ahi> <alo> <pl_lo> <pl_hi> <st_lo> <st_hi>
//                  <rx_lo> <rx_hi> <seen>
//     BB 66  <wc_lo> <wc_hi> <wb0..3> <st_idle_lo> <st_idle_hi> <wlog_n>
//            <ahi0> <alo0> <cnt0>  ... (wlog_n entries, 3 bytes each)
//            <cap_trigger> <cap_n> <cap0..capN-1>
//   AA 55         first-W diagnostic block
//   BB 66         write-log + capture block
//   wc            total completed W commands (u16 LE)
//   wb            total data bytes written (u32 LE, incl checksums)
//   st_idle       total stray bytes in IDLE (u16 LE)
//   wlog_n        number of 3-byte log entries that follow
//   each entry:   ahi, alo, count (raw header bytes from each W command)
//   cap_trigger   W command index that armed capture (u8)
//   cap_n         number of captured bytes (u8, 0 if trigger never fired)
//   cap0..N-1     raw bytes that entered IDLE after the trigger write
#ifndef OST_DBG_FIRSTW
#define OST_DBG_FIRSTW           0
#endif

// Ostrich reply payloads (Moates Ostrich serial spec v19,
// https://github.com/mstrand/ostrich2). Version reply = type, fw rev, letter:
// { 0x14, 0x09, 0x4F='O' }. TunerPro RT keys on the type byte; a wrong value
// greys out the Emulation Bank dropdown and falls back to a small legacy
// Ostrich that then rejects any larger bin.  The trailing letter is required
// by TunerPro's connection handshake — do not remove.
static const uint8_t OST_REPLY_VERSION[] = { 0x14, 0x09, 0x4F };
static const uint8_t OST_REPLY_SERIAL[]  = { 0x00, 0x04, 0x20, 0x04, 0x20,
                                             0x04, 0x20, 0x04, 0x20, 0x90 };
// Ostrich 2.0 FF reply: byte 0 = 0x04 (Ostrich 2.0 device ID).
// Byte 1 is reserved (0x01). The Moates protocol v19 spec does not include a
// "size" field in any reply — the emulation bank behaviour (see B+E+n in the
// state machine below) is what tells the host how much memory is presented
// to the target. The host (TunerPro RT) sends 'B','E',8,CS to enable 4-Mbit
// mode for 128 KB / 256 KB / 512 KB images, then uploads via R/W bank
// switching ('B','R',n,CS).
static const uint8_t OST_REPLY_INFO[]    = { 0x04, 0x01 };  // REV J debug: try 2-byte FF to see if TunerPro behaviour changes
#define OST_REPLY_STATUS_OK      0x4F        // 'O'  (reply to bare 'C''M')
// TunerPro mode: 'B''B' (bank) is a normal 2-byte opcode that replies 0x00.
// Z-mode: 'B' routes to the B-command state machine (BB silent, BRR -> 0x00).

//  Parser state

typedef enum {
    OST_IDLE = 0,        // waiting for a command's first byte
    OST_SECOND,          // have a 2-byte-opcode lead letter, awaiting partner
    OST_READ_PARAMS,     // collecting R's 4 header bytes (count, addrhi, addrlo, cksum)
    OST_WRITE_PARAMS,    // collecting W's 3 header bytes (count, addrhi, addrlo)
    OST_WRITE_DATA,      // streaming W payload into the image
    // Standard Ostrich mode (TunerPro RT) B-command tree.
    // Moates Ostrich 2.0 protocol v19: B+R+n+CS sets R/W bank, B+E+n+CS sets
    // emulation bank (n=0-7, or 8 = full 4-Mbit), B+S+n+CS sets persistent bank.
    // Read-backs: B+R+R+CS, B+E+R+CS, B+E+S+CS each reply with the stored n byte
    // followed by a trailing checksum byte. Real Ostrich validates checksums;
    // we follow the existing convention of accepting any trailing byte.
    OST_B_R_CMD,         // got 'B','R', awaiting 3rd byte (n for set, 'R' for read)
    OST_B_E_CMD,         // got 'B','E', awaiting 3rd byte
    OST_B_S_CMD,         // got 'B','S', awaiting 3rd byte
    OST_B_CKSUM,         // any B command, swallow trailing checksum byte
#ifdef OST_DT
    OST_TRACE_PARAMS,    // collecting T's 12 parameter bytes
#endif
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
    OST_HTZ_SYNC,        // waiting for command byte after 'Z' sync
    OST_HTZ_QUERY_CKSUM, // collecting checksum for query command
    OST_B_2ND,           // Z-mode: got 'B', awaiting 2nd byte
    OST_B_3RD,           // Z-mode: got 'B','R', awaiting 3rd byte ('R' -> reply 0x00)
    OST_B_CKSUM_Z,       // Z-mode: BRR replied, swallow trailing checksum byte
    OST_S_PARAM,         // Z-mode: got 'S', swallow param byte
    OST_S_CKSUM,         // Z-mode: got 'S',param, swallow checksum byte (silent)
    OST_POST_W_CHECK,    // Z-mode: W just completed, checking if real or false W
    OST_HTZ_WRITE_STREAM,// Z-mode W streaming — header + raw data to ROM
    OST_HTZ_AWAIT_Z,     // Z-mode: after Z-mode W block done, wait for next 'Z' sync
#endif
} ost_state_t;

typedef struct {
    ost_state_t state;

    uint8_t  lead;                      // first letter of a 2-byte opcode
    uint8_t  params[OST_RW_PARAM_LEN];
    uint8_t  param_len;

    uint32_t write_offset;
    uint32_t write_remaining;

    uint8_t  io_bank;
    uint8_t  emulation_bank;     // volatile emulation bank (0-7, or 8 = full 4 Mbit)
    uint8_t  emulation_bank_pers;// persistent emulation bank (no real persistence; mirrors volatile)
    uint8_t  rw_bank;            // volatile R/W bank (0-7); selects 64K page for R/W commands

    uint32_t dropped_oob;

#if PROTOCOL_MODE == PROTO_OSTRICH_Z
    uint8_t  htz_cmd;                   // command byte after 'Z' sync
    uint8_t  htz_cksum;                 // running checksum for Z-mode protocol
    bool     htz_active;                // current cmd came via 'Z' prefix (vs bare)
    bool     raw_mode;                  // raw binary write mode (no command framing)
    uint32_t raw_offset;                // current write offset in raw mode
    uint32_t raw_last_ms;               // board_millis() of last raw byte; exits raw mode after OST_RAW_IDLE_MS gap
    bool     w_completed_any;           // at least one W command completed (enables raw mode entry)
    uint32_t saved_write_offset;        // write_offset saved before suspected false W
    uint8_t  last_w_cksum;              // trailing checksum from last completed W
    uint32_t data_seq_addr;             // sequential ROM address for next data byte
    uint8_t  pending_raw_byte;          // first stray byte saved from POST_W_CHECK
    uint8_t  stray_count;               // consecutive stray bytes for raw mode threshold
    uint32_t htz_stream_remaining;      // Z-mode W streaming: bytes left to write
#endif

#ifdef OST_DT
    uint8_t  trace_params[12];          // T command's 12 param bytes (x1..CS) —
                                         // separate from params[]: OST_RW_PARAM_LEN
                                         // is 4 and must not grow for non-DT builds
    uint8_t  trace_param_len;           // bytes collected into trace_params so far
#endif
} ost_ctx_t;

// Default emulation bank = 8 (full 4 Mbit) so the target sees the entire
// rom_set. Moates Ostrich 2.0 boots with emulation bank 0 (64 KByte), but
// for our use case (OneROM presents the full rom_set) bank 8 is the right
// initial state — and a host that wants to set it explicitly will do so via
// 'B','E',8,CS before any upload anyway.
static ost_ctx_t ost = {
    .io_bank            = 0,
    .emulation_bank     = 8,
    .emulation_bank_pers= 8,
    .rw_bank            = 0,
};

//  First-block-drop diagnostic counters (compiled out unless OST_DBG_FIRSTW).
//  Integer-only; no I/O in the byte path, so timing is undisturbed.
#if OST_DBG_FIRSTW

// Write-log: record W command headers for post-mortem + raw capture.
#define OST_DBG_WLOG_MAX    8
typedef struct {
    uint8_t ahi;            // addr hi byte from the W header
    uint8_t alo;            // addr lo byte from the W header
    uint8_t count;          // count byte from the W header
} ost_wlog_entry_t;

// Post-write capture: first N bytes that enter IDLE after a trigger write.
#define OST_DBG_CAP_LEN     32

typedef struct {
    uint16_t rx_total;          // bytes fed to the parser this session
    uint16_t stray_idle;        // bytes ignored in IDLE (no command matched)
    uint16_t stray_before_w;    // snapshot of stray_idle when first 'W' framed
    uint16_t first_w_payload;   // payload bytes the first 'W' consumed
    uint8_t  first_w_count;     // count byte the first 'W' parsed
    uint8_t  first_w_ahi;       // addr hi the first 'W' parsed
    uint8_t  first_w_alo;       // addr lo the first 'W' parsed
    uint8_t  first_w_seen;      // a 'W' has been framed this session
    uint8_t  in_first_w;        // currently inside the first 'W' data phase
    // Aggregate write stats (all writes, not just first)
    uint16_t w_count;           // total completed W commands
    uint32_t w_bytes;           // total data bytes written (excl checksums)
    // Write log: every W command header (ahi, alo, count)
    ost_wlog_entry_t wlog[OST_DBG_WLOG_MAX];
    uint8_t  wlog_idx;          // next slot in wlog
    // Post-write raw capture
    uint8_t  cap_buf[OST_DBG_CAP_LEN];  // first bytes in IDLE after trigger
    uint8_t  cap_idx;          // next slot in cap_buf (0xFF = disabled)
    uint8_t  cap_trigger;      // fire after this many completed W commands
    uint8_t  w_completed;      // total W commands completed (for trigger)
    // Z-mode raw-binary diagnostics
    uint8_t  post_w_entered;   // times OST_POST_W_CHECK was entered
    uint8_t  raw_entered;      // times raw_mode was set true
    uint8_t  post_w_first_byte;// first byte that arrived in OST_POST_W_CHECK
    uint8_t  post_w_was_cmd;   // was that first byte a command?
    uint8_t  z_await_timeout;  // times OST_HTZ_AWAIT_Z timed out (no 'Z' within timeout)
    uint8_t  z_await_z_seen;   // times 'Z' arrived in OST_HTZ_AWAIT_Z (resumed normally)
} ost_dbg_t;
static ost_dbg_t ost_dbg;

#define DBG_RX_TICK()        do { ost_dbg.rx_total++; } while (0)
#define DBG_STRAY_TICK()     do { ost_dbg.stray_idle++; } while (0)
// Latch the first 'W' header as parsed (count byte + raw addr bytes).
#define DBG_FIRST_W(cb, ah, al) do {                              \
        if (!ost_dbg.first_w_seen) {                              \
            ost_dbg.first_w_seen     = 1;                         \
            ost_dbg.in_first_w       = 1;                         \
            ost_dbg.first_w_count    = (cb);                      \
            ost_dbg.first_w_ahi      = (ah);                      \
            ost_dbg.first_w_alo      = (al);                      \
            ost_dbg.stray_before_w   = ost_dbg.stray_idle;        \
        }                                                         \
    } while (0)
#define DBG_W_PAYLOAD_TICK() do {                                 \
        if (ost_dbg.in_first_w) ost_dbg.first_w_payload++;        \
        ost_dbg.w_bytes++;                                        \
    } while (0)
// On W completion: increment counter, arm capture after cap_trigger writes.
#define DBG_W_DONE() do {                                         \
        ost_dbg.in_first_w = 0;                                   \
        ost_dbg.w_count++;                                        \
        ost_dbg.w_completed++;                                    \
        if (ost_dbg.cap_idx == 0xFF &&                             \
            ost_dbg.w_completed == ost_dbg.cap_trigger) {         \
            ost_dbg.cap_idx = 0;                                  \
        }                                                         \
    } while (0)
// Log every W command header at the point where raw params are available.
#define DBG_LOG_W(_ahi, _alo, _cnt) do {                          \
        if (ost_dbg.wlog_idx < OST_DBG_WLOG_MAX) {               \
            ost_wlog_entry_t *_le = &ost_dbg.wlog[ost_dbg.wlog_idx];\
            _le->ahi   = (_ahi);                                  \
            _le->alo   = (_alo);                                  \
            _le->count = (_cnt);                                  \
            ost_dbg.wlog_idx++;                                   \
        }                                                         \
    } while (0)
// Capture first N bytes that enter IDLE after trigger fires.
#define DBG_POST_WRITE(_b) do {                                   \
        if (ost_dbg.cap_idx < OST_DBG_CAP_LEN) {                 \
            ost_dbg.cap_buf[ost_dbg.cap_idx] = (_b);             \
            ost_dbg.cap_idx++;                                    \
        }                                                         \
    } while (0)
#define DBG_POST_W_CHECK(_b, _is_cmd) do {                        \
        if (ost_dbg.post_w_entered < 255)                         \
            ost_dbg.post_w_entered++;                             \
        ost_dbg.post_w_first_byte = (_b);                         \
        ost_dbg.post_w_was_cmd = (_is_cmd) ? 1 : 0;              \
    } while (0)
#define DBG_RAW_ENTERED() do {                                    \
        if (ost_dbg.raw_entered < 255)                            \
            ost_dbg.raw_entered++;                                \
    } while (0)
#define DBG_Z_AWAIT_TIMEOUT() do {                                \
        if (ost_dbg.z_await_timeout < 255)                        \
            ost_dbg.z_await_timeout++;                            \
    } while (0)
#define DBG_Z_AWAIT_RESUME() do {                                 \
        if (ost_dbg.z_await_z_seen < 255)                         \
            ost_dbg.z_await_z_seen++;                             \
    } while (0)
#else
#define DBG_RX_TICK()        do { } while (0)
#define DBG_STRAY_TICK()     do { } while (0)
#define DBG_FIRST_W(cb, ah, al) do { (void)(cb); (void)(ah); (void)(al); } while (0)
#define DBG_W_PAYLOAD_TICK() do { } while (0)
#define DBG_W_DONE()         do { } while (0)
#define DBG_LOG_W(ahi, alo, cnt) do { } while (0)
#define DBG_POST_WRITE(b)    do { (void)(b); } while (0)
#define DBG_POST_W_CHECK(b, c) do { (void)(b); (void)(c); } while (0)
#define DBG_RAW_ENTERED()    do { } while (0)
#define DBG_Z_AWAIT_TIMEOUT() do { } while (0)
#define DBG_Z_AWAIT_RESUME() do { } while (0)
#endif

//  Flash persistence - debounced auto-commit (trigger/debounce half).
//  The flash commit itself is in the engine-bindings section (it needs the
//  One ROM + picoboot APIs). Everything collapses to no-ops unless
//  OST_PERSIST_ON_IDLE is set, and never builds in the host-test harness.
#if !defined(OST_HOST_TEST)
extern uint32_t board_millis(void);          // ms tick (usb_main.c)
#endif
#if OST_PERSIST_ON_IDLE && !defined(OST_HOST_TEST)
static bool ost_persist_commit(void);        // commits ONE physical 4KB block; true => more remain

static volatile bool     ost_persist_dirty   = false;
static volatile uint32_t ost_persist_last_ms = 0;

// Physical flash sector size. The active image is stored in RAM in a HARDWARE
// SERVING LAYOUT (address bits scrambled per the chip pin map by
// app_set_logical_byte_at_logical_addr), NOT as a flat logical array. So the
// commit must treat the RAM block as an opaque PHYSICAL region and bulk-copy it
// to flash verbatim (exactly as the boot preload reloads it) - it must NOT try
// to map logical addresses onto physical flash offsets. Doing so corrupts any
// sub-max EPROM (e.g. 27C010 emulating a smaller chip via pin re-map) whose
// logical->physical layout is interleaved, leaving half the physical image
// erased. We still chunk the copy into 4 KB
// PHYSICAL blocks (one per task call) for short critical sections, but every
// physical block is written - there is no logical "dirty sector" skipping.
//
// (The canonical FLASH_SECTOR_SIZE comes from usb_picobootx.h, included later;
// a _Static_assert in the bindings section pins OST_FLASH_SECTOR to it.)
#define OST_FLASH_SECTOR       4096u

// Drain cursor: physical byte offset of the next 4 KB block to commit. UINT32_MAX
// means "no drain in progress". Set to 0 when a commit is armed and idle elapses.
static volatile uint32_t ost_persist_phys_off = 0xFFFFFFFFu;

// Called on every completed WRITE: arm a full physical re-commit and (re)start
// the idle timer. lo/hi are unused now (kept for call-site compatibility) - the
// whole physical region is rewritten regardless of which logical bytes changed,
// because logical->physical is not a usable mapping here. The cursor is reset to
// "not started" so that a write arriving MID-DRAIN abandons the partial pass and
// restarts from block 0 after the new idle period - otherwise the new RAM bytes
// in already-committed blocks would be missed.
static inline void ost_persist_mark(uint32_t lo, uint32_t hi) {
    (void)lo; (void)hi;
    ost_persist_dirty    = true;
    ost_persist_phys_off = 0xFFFFFFFFu;       // restart any in-progress drain
    ost_persist_last_ms  = board_millis();
}

// Re-arm the idle debounce (no dirty change). Called per write byte so a long
// upload keeps the commit suppressed until the host is idle OST_PERSIST_IDLE_MS.
// Prevents a mid-upload commit (interrupts off) from stalling USB and dropping
// the next command's payload; also abandons any partial drain so it restarts
// cleanly after the upload finishes.
static inline void ost_persist_touch(void) {
    ost_persist_last_ms  = board_millis();
    ost_persist_phys_off = 0xFFFFFFFFu;       // abandon any partial drain
}

// Main-loop drain. Once writes are idle, commit the physical image in 4 KB
// blocks ONE PER CALL (short interrupts-off window each; tud_task runs between
// blocks so USB stays live). While blocks remain, dirty stays set and the idle
// timer is left un-stamped so the next iteration drains the next block. A write
// mid-drain re-stamps the timer and resets the cursor (via mark), restarting
// the drain from block 0 after the next idle period.
static void ost_persist_task(void) {
    if (!ost_persist_dirty) return;
    // Defer while a bare-W write is in flight (interrupts-off commit would drop
    // the next command's payload). Per-byte touch covers the streaming case.
    if (ost.state == OST_WRITE_DATA || ost.state == OST_WRITE_PARAMS) return;
    // Defer while RX is pending: a fresh upload's first bytes can arrive as an
    // armed commit is about to drain; that window would drop the first block.
    // Re-arm and abandon any partial drain so it restarts only once truly idle.
    if (tud_cdc_n_available(OST_CDC_ITF) > 0) { ost_persist_touch(); return; }
    if ((uint32_t)(board_millis() - ost_persist_last_ms) < OST_PERSIST_IDLE_MS) return;
    if (ost_persist_phys_off == 0xFFFFFFFFu) ost_persist_phys_off = 0u;  // start drain
    bool more = ost_persist_commit();         // one physical block
    if (!more) {                              // whole physical image flushed
        ost_persist_dirty    = false;
        ost_persist_phys_off = 0xFFFFFFFFu;
    }
    // if more: leave dirty set, timer un-advanced -> next iteration drains next block
}
#else
static inline void ost_persist_mark(uint32_t lo, uint32_t hi) { (void)lo; (void)hi; }
static inline void ost_persist_touch(void) {}
static inline void ost_persist_task(void) {}
#endif

//  Helpers

// params are (addrhi, addrlo) on the wire. Big-endian => (hi<<8)|lo.
static inline uint16_t ost_decode_addr(uint8_t a0, uint8_t a1) {
#if OST_ADDR_LITTLE_ENDIAN
    return (uint16_t)a0 | ((uint16_t)a1 << 8);
#else
    return (uint16_t)a1 | ((uint16_t)a0 << 8);
#endif
}

// Translate a count byte into a transfer length; count 0 => 256. In the shipping
// config (OST_COUNT_IS_BLOCKS=0) the value IS the byte length. The disproven
// block-count mode (=1) multiplies by OST_BLOCK_SIZE; kept only for bench A/B.
static inline uint32_t ost_count_to_bytes(uint8_t count_byte) {
    const uint32_t blocks = (count_byte == 0) ? 256u : (uint32_t)count_byte;
#if OST_COUNT_IS_BLOCKS
    return blocks * OST_BLOCK_SIZE;
#else
    return blocks;
#endif
}

// Map a host address to a flat ROM offset. Many ECUs place the EPROM in the
// UPPER part of the CPU address space - e.g. a 27C010 on a Delco/Holden ECU
// lives at 0x20000-0x3FFFF - so the host addresses the image high. We fold the
// address into the active ROM window by masking with (size-1). For a full-size
// image the mask spans the whole 19-bit address, so it is a no-op and the
// linear behaviour is preserved. EPROM sizes are always powers of two.
static inline uint32_t ost_flat_offset(uint8_t io_bank, uint16_t addr) {
    uint32_t off = (uint32_t)addr;
#if OST_BANK_AFFECTS_OFFSET
    off += (uint32_t)io_bank * OST_BANK_WINDOW_SIZE;
#else
    (void)io_bank;
#endif
    const uint32_t size = ostrich_active_rom_size();
    if (size != 0u && (size & (size - 1u)) == 0u)   // power of two
        off &= (size - 1u);                          // fold into [0, size)
    return off;
}

// Debug buffer for layout info - printed before first Ostrich read.
// Useful when the COM port can't be opened until after boot. 192 B of .bss
// and ~250 B of code, so off in production. Enable with:
//     make all OST_DEBUG_LAYOUT=1
#ifndef OST_DEBUG_LAYOUT
#define OST_DEBUG_LAYOUT 0
#endif
#if OST_DEBUG_LAYOUT
static char     ost_dbg_buf[192];
static uint32_t ost_dbg_len = 0;
static bool     ost_dbg_sent = false;

static void ost_build_debug(void);  // forward decl

// Append 3-digit decimal representation of b to buf at *pn. No-op if no room.
static void append_u8_dec(char *buf, uint32_t buf_sz, uint32_t *pn, uint8_t b) {
    if (*pn + 3 > buf_sz) return;
    buf[(*pn)++] = '0' + (b / 100);
    buf[(*pn)++] = '0' + ((b / 10) % 10);
    buf[(*pn)++] = '0' + (b % 10);
}

// Append literal string to buf at *pn.
static void append_str(char *buf, uint32_t buf_sz, uint32_t *pn, const char *s) {
    while (*s && *pn < buf_sz) buf[(*pn)++] = *s++;
}
#endif

// Send to CDC 0. Do NOT gate on tud_cdc_n_connected() (DTR) - TunerPro may not
// raise DTR and gating would swallow replies. Bounded spin guard avoids hangs.
static void ost_send(const uint8_t *buf, uint32_t len) {
    // First flush the debug buffer (once) so it appears before the first
    // response. Useful for diagnosis when COM port can't be opened at boot.
#if OST_DEBUG_LAYOUT
    if (!ost_dbg_sent && ost_dbg_len > 0) {
        // Recursive call is safe — ost_dbg_sent guards against re-entry.
        ost_dbg_sent = true;
        ost_send((const uint8_t *)ost_dbg_buf, ost_dbg_len);
    }
#endif
    uint32_t sent = 0, stalls = 0;
    while (sent < len) {
        uint32_t space = tud_cdc_n_write_available(OST_CDC_ITF);
        if (space == 0) {
            tud_cdc_n_write_flush(OST_CDC_ITF);
            tud_task();
            if (++stalls > OST_SEND_MAX_STALLS) break;
            continue;
        }
        stalls = 0;
        uint32_t chunk = len - sent;
        if (chunk > space) chunk = space;
        sent += tud_cdc_n_write(OST_CDC_ITF, buf + sent, chunk);
    }
    tud_cdc_n_write_flush(OST_CDC_ITF);
#ifdef OST_TRACE_TX
    // Mirror outgoing bytes to the Trace CDC so a host logger can capture
    // exactly what the Ostrich replies. Best-effort: drop on full FIFO
    // rather than stall the Ostrich path. Combined with OST_TRACE_RX the
    // trace contains both directions.
#if !UART_CDC_PRESENT
#error "OST_TRACE_TX needs the Trace CDC present - do not use with UART_MODE_DISABLED"
#endif
    {
        uint32_t avail = tud_cdc_n_write_available(1);
        uint32_t to_copy = (len < avail) ? len : avail;
        if (to_copy > 0) {
            tud_cdc_n_write(1, buf, to_copy);
            tud_cdc_n_write_flush(1);
        }
    }
#endif
}

static inline void ost_send_byte(uint8_t b) { ost_send(&b, 1); }

//  Command actions

// READ: 'R' count addrhi addrlo cksum.  count = byte count (0 => 256) in the
// shipping config (OST_COUNT_IS_BLOCKS=0). Streams that many bytes from the
// absolute address, then - if OST_READ_TRAILER - one trailing byte = (sum of
// returned data) & 0xFF. Output is emitted in OST_BLOCK_SIZE chunks via a single
// stack buffer, so even a maximal read never grows the stack with the payload.
//
    // Per Moates Ostrich 2.0 protocol, the 16-bit 'R' address is relative to the
    // currently selected R/W bank (0-7). The full 19-bit rom_set address is
    //   (rw_bank << 16) | addr
    // so e.g. R/W bank 2 + addr 0x0000 = rom_set offset 0x20000.
    //
    // TunerPro RT 5 quirk: when uploading a 27C010 (128 KB) bin, it selects
    // R/W banks 6 then 7 and writes the two 64 KB halves to rom_set offsets
    // 0x60000-0x7FFFF instead of 0+1 -> 0x00000-0x1FFFF. The image is meant
    // for the 27C010 EPROM, which the OneROM PIO reads from offsets
    // 0x00000-0x1FFFF (the lower 128 KB of the 512 KB rom_set). To make the
    // upload land where the EPROM pins actually read from, remap bank 6
    // -> 0x00000-0x0FFFF and bank 7 -> 0x10000-0x1FFFF.
static void ost_handle_read(uint8_t count_byte, uint16_t addr) {
    const uint32_t total = ost_count_to_bytes(count_byte);
    const uint32_t size  = ostrich_active_rom_size();
    // Bank 8 = "full 4 Mbit" mode per Moates spec — the address is the full
    // rom_set starting at 0, not (8 << 16) | addr which would be out of range
    // for any rom_set < 1 MB. ZW writes already use rom_addr directly (no
    // rw_bank shift), so this also keeps the read addressing consistent with
    // the write addressing in the Ostrich 2.0 bank 8 case.
    // Banks 6 and 7: remap to 0x00000-0x0FFFF and 0x10000-0x1FFFF so the
    // 27C010 image lands in the lower 128 KB where the EPROM pins read.
    uint32_t base;
    if (ost.rw_bank == 6) {
        base = (uint32_t)addr;
    } else if (ost.rw_bank == 7) {
        base = 0x10000u + (uint32_t)addr;
    } else if (ost.rw_bank == 8) {
        base = (uint32_t)addr;
    } else {
        base = ((uint32_t)ost.rw_bank << 16) | (uint32_t)addr;
    }

    uint8_t  chunk[OST_BLOCK_SIZE];
    uint8_t  sum  = 0;
    uint32_t done = 0;

    while (done < total) {
        uint32_t m = total - done;
        if (m > OST_BLOCK_SIZE) m = OST_BLOCK_SIZE;
        for (uint32_t i = 0; i < m; i++) {
            uint32_t off = base + done + i;
            uint8_t  v   = (off < size) ? ostrich_rom_read_byte(off) : 0xFF;
            chunk[i] = v;
            sum = (uint8_t)(sum + v);
        }
        ost_send(chunk, m);
        done += m;
    }

#if OST_READ_TRAILER
    ost_send_byte(sum);   // trailing checksum = sum of returned data
#endif
}

// WRITE: 'W' count addrhi addrlo, then <count> data bytes (count 0 => 256) and
// one checksum byte trailing the data (NOT in the header - W's header is 3 bytes;
// cf. R, whose checksum is the 4th header byte). On completion reply 'O' (0x4F).
// Writes are clamped to the active ROM size, so an over-range upload is
// truncated, never faulted.
static void ost_begin_write(uint8_t count_byte, uint16_t addr) {
    // Banks 6 and 7: remap to 0x00000-0x0FFFF and 0x10000-0x1FFFF so a
    // 27C010 image uploaded by TunerPro RT 5 lands in the lower 128 KB
    // where the EPROM pins read. See ost_handle_read for the matching
    // read-side remap.
    if (ost.rw_bank == 6) {
        ost.write_offset = (uint32_t)addr;
    } else if (ost.rw_bank == 7) {
        ost.write_offset = 0x10000u + (uint32_t)addr;
    } else if (ost.rw_bank == 8) {
        ost.write_offset = (uint32_t)addr;
    } else {
        ost.write_offset = ((uint32_t)ost.rw_bank << 16) | (uint32_t)addr;
    }
    ost.write_remaining = ost_count_to_bytes(count_byte) + 1u; // +1 = trailing cksum
    ost.state           = OST_WRITE_DATA;
    ost_persist_touch();                         // keep the commit away during upload
}

static inline void ost_write_payload_byte(uint8_t b) {
    ost_persist_touch();                         // push debounce on every write byte
    DBG_W_PAYLOAD_TICK();                         // diag: count payload of the first W
    if (ost.write_remaining > 1u) {              // data byte (last byte is cksum)
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
        // Z-mode: bank header Ws (16 bytes to 0x0080-0x00F0) write each
        // byte to its correct ROM address: slot * 0x1000 + 0x80 + data_idx.
        // Non-bank-header Ws (count != 16 or target outside range) write to
        // the flat write_offset for TunerPro compatibility.
        {
            const uint16_t target = ost_flat_offset(ost.io_bank,
                (uint16_t)((ost.params[1] << 8) | ost.params[2]));
            const uint16_t count = ost_count_to_bytes(ost.params[0]);
            const uint32_t data_idx = count - ost.write_remaining + 1;

            if (target >= 0x0080 && target <= 0x00F0 && count == 16) {
                // Bank header W: write to slot * 0x1000 + 0x80 + data_idx.
                // Z-mode host packs 8 bank headers at flat 0x0080-0x00F0; each 16-byte
                // chunk maps to slot*0x1000+0x80 in the One ROM slot layout.
                const uint8_t slot = (target - 0x0080) / 16;
                const uint32_t rom_addr = slot * 0x1000u + 0x80u + data_idx;
                if (rom_addr < ostrich_active_rom_size()) {
                    ostrich_rom_write_byte(rom_addr, b);
                } else {
                    ost.dropped_oob++;
                }
            } else {
                // Non-bank-header W: write to flat offset (TunerPro-compatible)
                if (ost.write_offset < ostrich_active_rom_size()) {
                    ostrich_rom_write_byte(ost.write_offset, b);
                } else {
                    ost.dropped_oob++;
                }
            }
        }
#else
        if (ost.write_offset < ostrich_active_rom_size()) {
            ostrich_rom_write_byte(ost.write_offset, b);
        } else {
            ost.dropped_oob++;
        }
#endif
        ost.write_offset++;                     // always track for raw mode offset
    } else {
        (void)b;                                 // trailing checksum: consume only
    }
    ost.write_remaining--;
    if (ost.write_remaining == 0) {
        ost_send_byte(OST_WRITE_REPLY);          // 'O' = OK
        DBG_W_DONE();                            // diag: first-W data phase ended
        ost_persist_mark(0u, 0u);                // arm the debounced full-image commit
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
        if (ost.w_completed_any) {
            ost.last_w_cksum = b;                // save trailing byte for false-W recovery
            ost.state = OST_POST_W_CHECK;        // verify: real W or false W?
        } else {
            ost.state = OST_IDLE;
            ost.w_completed_any = true;          // enable raw mode entry on next stray
        }
#else
        ost.state = OST_IDLE;
#endif
    }
}

// Resolve a completed 2-byte opcode (lead, b). Returns true if it matched a
// known query command (and the reply was sent).
static bool ost_try_opcode(uint8_t lead, uint8_t b) {
    if (lead == 'V' && b == 'V') { ost_send(OST_REPLY_VERSION, sizeof OST_REPLY_VERSION); return true; }
    if (lead == 'N' && b == 'S') { ost_send(OST_REPLY_SERIAL,  sizeof OST_REPLY_SERIAL);  return true; }
    if (lead == 'F' && b == 'F') {
        ost_send(OST_REPLY_INFO, sizeof OST_REPLY_INFO);   // base reply: 04 01
#if OST_DBG_FIRSTW
        // Append the first-block-drop diagnostic block. Magic AA 55 lets the
        // probe locate it; everything after is fixed-width (see header comment).
        uint8_t d[11];
        d[0]  = 0xAA;
        d[1]  = 0x55;
        d[2]  = ost_dbg.first_w_count;
        d[3]  = ost_dbg.first_w_ahi;
        d[4]  = ost_dbg.first_w_alo;
        d[5]  = (uint8_t)(ost_dbg.first_w_payload & 0xFF);
        d[6]  = (uint8_t)(ost_dbg.first_w_payload >> 8);
        d[7]  = (uint8_t)(ost_dbg.stray_before_w & 0xFF);
        d[8]  = (uint8_t)(ost_dbg.stray_before_w >> 8);
        d[9]  = (uint8_t)(ost_dbg.rx_total & 0xFF);
        d[10] = (uint8_t)(ost_dbg.rx_total >> 8);
        ost_send(d, sizeof d);
        ost_send_byte(ost_dbg.first_w_seen);
        // Append write-log block. Magic BB 66, then aggregate stats + wlog + capture.
        {
            uint8_t hdr[11];
            hdr[0] = 0xBB;
            hdr[1] = 0x66;
            hdr[2] = (uint8_t)(ost_dbg.w_count & 0xFF);
            hdr[3] = (uint8_t)(ost_dbg.w_count >> 8);
            hdr[4] = (uint8_t)(ost_dbg.w_bytes & 0xFF);
            hdr[5] = (uint8_t)((ost_dbg.w_bytes >> 8) & 0xFF);
            hdr[6] = (uint8_t)((ost_dbg.w_bytes >> 16) & 0xFF);
            hdr[7] = (uint8_t)((ost_dbg.w_bytes >> 24) & 0xFF);
            hdr[8] = (uint8_t)(ost_dbg.stray_idle & 0xFF);
            hdr[9] = (uint8_t)(ost_dbg.stray_idle >> 8);
            hdr[10] = ost_dbg.wlog_idx;
            ost_send(hdr, sizeof hdr);
        }
        // Dump the wlog: each entry is 3 bytes (ahi, alo, count)
        if (ost_dbg.wlog_idx > 0) {
            ost_send((const uint8_t *)ost_dbg.wlog,
                     (uint32_t)ost_dbg.wlog_idx * sizeof(ost_wlog_entry_t));
        }
        // Dump the post-write capture buffer
        {
            uint8_t cap_hdr[2];
            cap_hdr[0] = ost_dbg.cap_trigger;  // trigger config
            cap_hdr[1] = (ost_dbg.cap_idx == 0xFF) ? 0 : ost_dbg.cap_idx;  // bytes captured
            ost_send(cap_hdr, sizeof cap_hdr);
            if (ost_dbg.cap_idx > 0 && ost_dbg.cap_idx != 0xFF) {
                ost_send(ost_dbg.cap_buf, ost_dbg.cap_idx);
            }
        }
        // Append Z-mode raw-binary diagnostics. Magic CC 77.
        {
            uint8_t h[6];
            h[0] = 0xCC;
            h[1] = 0x77;
            h[2] = ost_dbg.post_w_entered;
            h[3] = ost_dbg.raw_entered;
            h[4] = ost_dbg.z_await_timeout;
            h[5] = ost_dbg.z_await_z_seen;
            ost_send(h, sizeof h);
            // byte 6: first byte that arrived in POST_W_CHECK
            // byte 7: was it a command? (1=yes, 0=no → entered raw)
            ost_send_byte(ost_dbg.post_w_first_byte);
            ost_send_byte(ost_dbg.post_w_was_cmd);
        }
#endif
        return true;
    }
    // A real Moates Ostrich is SILENT on BB. Z-mode host expects no reply;
    // answering desyncs the Z-mode parser by one byte and connection fails.
    // 'B' is NOT a lead in Z-mode - it routes to the B-command state
    // machine (BB silent, BRR -> 0x00). See ost_feed_once OST_B_* states.
    if (lead == 'C' && b == 'M') { ost_send_byte(OST_REPLY_STATUS_OK);                    return true; }
#if PROTOCOL_MODE != PROTO_OSTRICH_Z
    if (lead == 'B' && b == 'B') { ost_send_byte(0x00);                                   return true; }  // bank query
#endif
    return false;
}

static inline bool ost_is_lead(uint8_t b) {
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
    // HTS: 'B' is NOT a lead - device stays silent on BB; BRR is handled
    // by the B-command state machine. 'S' is also not a lead - handled
    // separately (swallow param+cksum, no reply).
    // 'C' IS a lead - CM returns 0x4F (identical to TunerPro).
#ifdef OST_DT
    return b == 'V' || b == 'N' || b == 'F' || b == 'C' || b == 'T';
#else
    return b == 'V' || b == 'N' || b == 'F' || b == 'C';
#endif
#else
#ifdef OST_DT
    return b == 'V' || b == 'N' || b == 'F' || b == 'C' || b == 'B' || b == 'T';
#else
    return b == 'V' || b == 'N' || b == 'F' || b == 'C' || b == 'B';
#endif
#endif
}

#ifdef OST_DT
// Execute a completed 'T' trace command (12 bytes collected in ost.trace_params:
// x1,x2,x3,y1,y2,sMMSB,sMSB,sLSB,eMMSB,eMSB,eLSB,CS). Shared by both the bare
// Ostrich and Z-mode dispatchers — deliberately at unconditional file scope
// (only gated by OST_DT, not PROTOCOL_MODE) since both call it. Returns true
// if the command completed (non-streaming) and the caller should go to IDLE.
static bool ost_trace_report(void) {
    uint8_t x1 = ost.trace_params[0];   // subcommand bitmask
    // x2, x3 = ost.trace_params[1,2]  // reserved
    uint8_t y1 = ost.trace_params[3];   // hits to buffer
    // y2 = ost.trace_params[4]        // packets to report (unused for now)
    // sMMSB:sMSB:sLSB = ost.trace_params[5,6,7]  // start address window
    // eMMSB:eMSB:eLSB = ost.trace_params[8,9,10] // end address window
    // CS = ost.trace_params[11]       // checksum (ignored, matches Ostrich convention)

    // Address byte count from x1 bits 6-7 (0/3 = all 3 bytes, 1 = LSB, 2 = MSB:LSB)
    uint8_t addr_bytes = 3;
    if ((x1 & 0xC0) == 0x40) addr_bytes = 1;
    else if ((x1 & 0xC0) == 0x80) addr_bytes = 2;

    bool non_streaming = (x1 & 0x01) != 0;
    bool windowed      = (x1 & 0x02) != 0;
    bool nonredundant   = (x1 & 0x04) != 0;
    (void)windowed; (void)nonredundant;  // TODO: implement filtering

    uint8_t hits_reported = 0;
    ost_send_byte('O');  // ack

    while (hits_reported < y1) {
        uint32_t logical_addr;
        if (!usb_dt_get_capture(&logical_addr)) break;  // ring empty

        if (addr_bytes >= 3) ost_send_byte((logical_addr >> 16) & 0xFF);  // MMSB
        if (addr_bytes >= 2) ost_send_byte((logical_addr >> 8) & 0xFF);   // MSB
        ost_send_byte(logical_addr & 0xFF);                               // LSB
        hits_reported++;
    }

    ost_send_byte('O');  // end packet
    ost.trace_param_len = 0;
    // TODO: real streaming (non_streaming==false) needs continuous unsolicited
    // bursts + 't' soft-stop + hard-interrupt-on-any-byte per spec; not yet
    // implemented — caller currently just re-arms for another full T command.
    return non_streaming;
}
#endif

//  HTS Protocol (PROTO_OSTRICH_Z) - 'Z'-prefixed commands with checksum       //
//  NOTE: HTS sends bare commands (no Z prefix). The Z-prefix path is    //
//  retained for compatibility but HTS does not use it. The actual HTS   //
//  connect sequence is: VV, NS+cksum, BRR+cksum (->0x00), S+param+cksum //
//  (silent). BRR and S are handled in ost_feed_once OST_B_*/OST_S_*     //
//  states, NOT here.                                                    //
#if PROTOCOL_MODE == PROTO_OSTRICH_Z

// HTS protocol uses 'Z' (0x5A) as sync byte before each command.
// Format: Z <cmd> <params...> <checksum>
// Checksum = sum of all bytes (Z + cmd + params) & 0xFF

static inline bool htz_is_query_cmd(uint8_t cmd) {
    return cmd == 'V' || cmd == 'N' || cmd == 'F' || cmd == 'C' || cmd == 'B';
}


static void htz_handle_query(uint8_t cmd, uint8_t cksum) {
    // Verify checksum: HTS sends direct sum (low byte), not complement.
    // cksum should equal (Z + cmd) & 0xFF.
    uint8_t expected = (uint8_t)(0x5A + cmd);
    if (cksum != expected) {
        return;  // checksum mismatch
    }

    // Execute the command (same as Ostrich but with 'Z' prefix context)
    if (cmd == 'V') { ost_send(OST_REPLY_VERSION, sizeof OST_REPLY_VERSION); }
    else if (cmd == 'N') { ost_send(OST_REPLY_SERIAL, sizeof OST_REPLY_SERIAL); }
    else if (cmd == 'F') { ost_send(OST_REPLY_INFO, sizeof OST_REPLY_INFO); }
    else if (cmd == 'C') { ost_send_byte(OST_REPLY_STATUS_OK); }
    else if (cmd == 'B') { ost_send_byte(0x00); }  // bank query
}

// Handle a complete HTS read command: Z R <count> <addrhi> <addrlo> <cksum>
// Z-mode count is BLOCKS (×256), not raw bytes like bare R.
static void htz_handle_read(uint8_t count_byte, uint8_t ahi, uint8_t alo, uint8_t cksum) {
    // Verify checksum: HTS sends direct sum (low byte), not complement.
    // cksum should equal (Z + R + count + ahi + alo) & 0xFF.
    uint8_t expected = (uint8_t)(0x5A + 'R' + count_byte + ahi + alo);
    if (cksum != expected) {
        return;  // checksum mismatch
    }
    // ZR format per Moates spec: Z R count MMSB MSB <data> CS. The base
    // address is (MMSB << 16) | (MSB << 8) — same 19-bit form as ZW, NOT
    // the 16-bit (ahi<<8)|alo used by bare R. The old code used bare-R
    // 16-bit addressing here, which made ZR reads of addresses ≥ 0x10000
    // hit a totally different rom_data[] slot than the matching ZW write.
    const uint32_t addr = ((uint32_t)ahi << 16) | ((uint32_t)alo << 8);
    uint32_t base;
    if (ahi == 0 && alo == 0x01) {
        // Legacy slot-0 read: HTS's pre-bank-switching reads target
        // address 0x0100 (alo<<8); remap to ROM base 0. Backward-compat only.
        (void)addr;
        base = 0u;
    } else {
        base = addr;
    }
    // Z-mode count is blocks × 256 (count=0 means 256 blocks = 65536).
    const uint32_t total = (count_byte == 0) ? 65536u : (uint32_t)count_byte * 256u;
    const uint32_t size  = ostrich_active_rom_size();

    uint8_t  chunk[OST_BLOCK_SIZE];
    uint8_t  sum  = 0;
    uint32_t done = 0;

    while (done < total) {
        uint32_t m = total - done;
        if (m > OST_BLOCK_SIZE) m = OST_BLOCK_SIZE;
        for (uint32_t i = 0; i < m; i++) {
            uint32_t off = base + done + i;
            uint8_t  v   = (off < size) ? ostrich_rom_read_byte(off) : 0xFF;
            chunk[i] = v;
            sum = (uint8_t)(sum + v);
        }
        ost_send(chunk, m);
        done += m;
    }

#if OST_READ_TRAILER
    ost_send_byte(sum);   // trailing checksum = sum of returned data
#endif
}

// Begin an HTS write: Z W <count> <addrhi> <addrlo> (checksum trails data)
static void htz_begin_write(uint8_t count_byte, uint8_t ahi, uint8_t alo) {
    ost_begin_write(count_byte, ost_decode_addr(ahi, alo));
    ost.htz_cksum = (uint8_t)(0x5A + 'W' + count_byte + ahi + alo);
}

#endif // PROTOCOL_MODE == PROTO_OSTRICH_Z

//  Engine bindings (One ROM). Skipped in host-test builds.
#ifndef OST_HOST_TEST

#include "usb_plugin.h"
#include "usb_rom.h"
#include "usb_picobootx.h"

// OST_FLASH_SECTOR (defined earlier, before this include was available) must
// match the canonical sector size. If the platform ever changes it, fail the
// build instead of silently mis-sizing the dirty-sector commits.
#if OST_PERSIST_ON_IDLE
_Static_assert(OST_FLASH_SECTOR == FLASH_SECTOR_SIZE,
               "OST_FLASH_SECTOR must equal FLASH_SECTOR_SIZE");
#endif

extern usb_plugin_context_t context;

static rom_pin_layout_t ost_layout;
static bool             ost_layout_valid = false;

#if OST_DEBUG_LAYOUT
static void ost_build_debug(void) {
    if (ost_dbg_len > 0) return;  // already built
    char *buf = ost_dbg_buf;
    uint32_t n = 0;
    uint32_t sz = sizeof(ost_dbg_buf);

    // Header: OST: valid=N numbits=N romsize=N chip=N rsi=N
    append_str(buf, sz, &n, "OST: valid=");
    append_u8_dec(buf, sz, &n, ost_layout_valid ? 1 : 0);
    append_str(buf, sz, &n, " numbits=");
    append_u8_dec(buf, sz, &n, ost_layout.num_addr_bits);
    append_str(buf, sz, &n, " romsize=");
    uint32_t rsize = context.runtime ? context.runtime->rom_table_size : 0;
    append_u8_dec(buf, sz, &n, (rsize >> 16) & 0xff);
    append_u8_dec(buf, sz, &n, (rsize >> 8) & 0xff);
    append_u8_dec(buf, sz, &n, rsize & 0xff);
    append_str(buf, sz, &n, " chip=");
    append_u8_dec(buf, sz, &n, ost_layout.chip_pins);
    if (context.runtime) {
        append_str(buf, sz, &n, " rsi=");
        append_u8_dec(buf, sz, &n, context.runtime->rom_set_index);
    }
    if (n + 2 < sz) { buf[n++] = '\r'; buf[n++] = '\n'; }

    // addr_gpio
    append_str(buf, sz, &n, "  addr:");
    for (int i = 0; i < 16; i++) {
        if (n + 4 < sz) buf[n++] = ' ';
        append_u8_dec(buf, sz, &n, ost_layout.addr_gpio[i]);
    }
    if (n + 2 < sz) { buf[n++] = '\r'; buf[n++] = '\n'; }

    // data_gpio (D0-D7)
    append_str(buf, sz, &n, "  data:");
    for (int i = 0; i < 8; i++) {
        if (n + 4 < sz) buf[n++] = ' ';
        append_u8_dec(buf, sz, &n, ost_layout.data_gpio[i]);
    }
    if (n + 2 < sz) { buf[n++] = '\r'; buf[n++] = '\n'; }

    // cs1 cs2 rom_type
    append_str(buf, sz, &n, "  cs1=");
    append_u8_dec(buf, sz, &n, ost_layout.cs1);
    append_str(buf, sz, &n, " cs2=");
    append_u8_dec(buf, sz, &n, ost_layout.cs2);
    append_str(buf, sz, &n, " rt=");
    append_u8_dec(buf, sz, &n, ost_layout.rom_type);
    if (n + 2 < sz) { buf[n++] = '\r'; buf[n++] = '\n'; }

    ost_dbg_len = n;
}
#endif // OST_DEBUG_LAYOUT

static void ost_engine_init(void) {
    ost_layout_valid =
        (app_retrieve_pin_layout(&context, &ost_layout) == PB_STATUS_OK);
#if OST_DEBUG_LAYOUT
    ost_build_debug();
#endif
}

uint32_t ostrich_active_rom_size(void) {
#if OST_FORCE_ROM_SIZE
    return OST_FORCE_ROM_SIZE;                // pinned size (e.g. 32768u = 32 KB)
#else
    return app_get_active_rom_size(&context); // follow the configured chip type
#endif
}

// app_get/set_logical_byte_at_logical_addr take a 0-based logical address (the
// picoboot range path strips the 0x90000000 base with & 0x0FFFFFFF before
// calling them). Our flat offset IS that 0-based logical address, so pass it
// straight through. (Verified against usb_rom.c / usb_picobootx.c.)
uint8_t ostrich_rom_read_byte(uint32_t offset) {
    if (!ost_layout_valid) return 0xFF;
    uint32_t value = 0xFF;
    if (app_get_logical_byte_from_logical_addr(
            offset, &value, &ost_layout, &context) != PB_STATUS_OK) {
        return 0xFF;
    }
    return (uint8_t)value;
}

void ostrich_rom_write_byte(uint32_t offset, uint8_t value) {
    if (!ost_layout_valid) return;
    (void)app_set_logical_byte_at_logical_addr(
        offset, value, &ost_layout, &context);
}

void ostrich_set_emulation_window(uint8_t bank) { (void)bank; }

#if OST_PERSIST_ON_IDLE
// Flash commit - write the live RAM image back to the flash slot it was
// preloaded from, so Ostrich uploads survive a power cycle.
//
// Mirrors picobootx's flash_erase_critical: a single RAM-resident critical
// section, interrupts off, that exits XIP, erases the ROM sectors, programs
// them from the RAM image, then restores XIP read mode. The bootrom flash
// routines (looked up via picoboot_lookup_boot_fn) execute from ROM and the
// source image is in SRAM, so nothing runs from flash while XIP is down. Erase
// and program share one window, so there is no power-loss gap where the region
// is erased but not yet reprogrammed. This runs in the same main-loop context
// as the picoboot flashing path, which already erases/programs flash on this
// hardware while the ROM is being served from RAM.

// XIP/QMI clock-divisor register, used to restore XIP read mode after the
// program (same value picobootx reads). Local copy, as the host-control plugin.
#define OST_XIP_QMI_M0_TIMING  (*((volatile uint32_t *)(0x400d0000u + 0x0Cu)))

// End of the 128 KB protected flash region (firmware 64 KB + system plugin
// 64 KB), as an XIP address - this is the space rs->data / flash_addr live in,
// so it MUST include the 0x10000000 flash base (= 0x10020000), NOT a bare
// 0x20000 offset. The served ROM image begins exactly here. Defined locally
// only if the engine headers didn't export it, so this TU always compiles.
#ifndef FLASH_PROTECTED_END
#define FLASH_PROTECTED_END  (RP2350_FLASH_BASE + 128u * 1024u)   // 0x10020000
#endif

typedef void (*ost_cif_fn)(void);                                              // connect_internal_flash
typedef void (*ost_exx_fn)(void);                                              // flash_exit_xip
typedef void (*ost_ers_fn)(uint32_t off, uint32_t count, uint32_t blk, uint8_t cmd); // range_erase
typedef void (*ost_prg_fn)(uint32_t off, const uint8_t *data, uint32_t count);  // range_program
typedef void (*ost_flc_fn)(void);                                              // flush_cache
typedef void (*ost_sxm_fn)(uint8_t mode, uint8_t clkdiv);                       // select_xip_read_mode

// MUST run from RAM: between exit_xip() and select_xip() flash is inaccessible,
// so no flash-resident code may execute (interrupts off, .ramfunc, noinline).
static void __attribute__((section(".ramfunc"), noinline)) ost_flash_commit_critical(
    ost_cif_fn connect_internal_flash, ost_exx_fn exit_xip,
    ost_ers_fn range_erase, ost_prg_fn range_program,
    ost_flc_fn flush_cache, ost_sxm_fn select_xip,
    uint32_t flash_offs, const uint8_t *src,
    uint32_t erase_size, uint32_t prog_size, uint8_t clkdiv)
{
    __asm volatile ("cpsid i");
    connect_internal_flash();
    exit_xip();
    range_erase(flash_offs, erase_size, FLASH_BLOCK_SIZE, FLASH_BLOCK_ERASE_CMD);
    range_program(flash_offs, src, prog_size);
    select_xip(3, clkdiv);
    flush_cache();
    __asm volatile ("cpsie i");
}

// Commit ONE physical 4 KB block (at ost_persist_phys_off) of the active image
// to flash and return true if more blocks remain. This is a verbatim PHYSICAL
// copy of the RAM serving image to its flash slot - identical bytes to what the
// boot preload reloads - just chunked so each interrupts-off window covers one
// 4 KB block instead of the whole image. It deliberately does NOT interpret the
// logical layout (see ost_persist_mark). Same validation/primitives as the
// original whole-image commit. If anything needed is unavailable, the drain is
// ended (returns false) so it can never spin forever.
static bool ost_persist_commit(void) {
    // Flash destination: the slot the active image was preloaded from at boot.
    const sdrr_rom_set_t *rs = app_get_active_rom_set(&context);
    if (rs == NULL || rs->data == NULL || rs->size == 0u) return false;
    uint32_t flash_addr = (uint32_t)(uintptr_t)rs->data;   // XIP addr, 0x10xxxxxx
    uint32_t size       = rs->size;

    // Never touch the protected firmware/plugin region; require alignment.
    if (flash_addr < FLASH_PROTECTED_END)        return false;
    if ((flash_addr % FLASH_SECTOR_SIZE) != 0u)  return false;
    if ((size % 256u) != 0u || size == 0u)       return false;  // whole pages only

    // RAM source: the live (modified) image currently being served.
    if (context.ora_lookup_fn == NULL) return false;
    ora_get_active_ram_slot_fn_t get_active = context.ora_lookup_fn(ORA_ID_GET_ACTIVE_RAM_SLOT);
    ora_get_ram_slot_info_fn_t   get_info   = context.ora_lookup_fn(ORA_ID_GET_RAM_SLOT_INFO);
    if (get_active == NULL || get_info == NULL) return false;
    uint8_t slot = 0;
    if (get_active(&slot) != ORA_RESULT_OK) return false;
    uint32_t ram_addr = 0u, ram_size = 0u;
    if (get_info(slot, &ram_addr, &ram_size, NULL) != ORA_RESULT_OK) return false;
    if (ram_addr == 0u || ram_size < size) return false;  // sanity

    // Current physical block; if past the end, nothing more to do.
    uint32_t off = ost_persist_phys_off;
    if (off >= size) return false;

    // Bootrom flash primitives.
    ost_cif_fn cif = (ost_cif_fn)picoboot_lookup_boot_fn('I','F');
    ost_exx_fn exx = (ost_exx_fn)picoboot_lookup_boot_fn('E','X');
    ost_ers_fn ers = (ost_ers_fn)picoboot_lookup_boot_fn('R','E');
    ost_prg_fn prg = (ost_prg_fn)picoboot_lookup_boot_fn('R','P');
    ost_flc_fn flc = (ost_flc_fn)picoboot_lookup_boot_fn('F','C');
    ost_sxm_fn sxm = (ost_sxm_fn)picoboot_lookup_boot_fn('X','M');
    if (!cif || !exx || !ers || !prg || !flc || !sxm) return false;

    uint32_t flash_offs = flash_addr - RP2350_FLASH_BASE;
    uint8_t  clkdiv     = (uint8_t)(OST_XIP_QMI_M0_TIMING & 0xFFu);

    // This physical block: erase 4 KB, program min(4 KB, remaining). size is a
    // multiple of 256, so the tail program size is a whole number of pages.
    uint32_t remain    = size - off;
    uint32_t prog_size = (remain < OST_FLASH_SECTOR) ? remain : OST_FLASH_SECTOR;

    // SKIP-IF-UNCHANGED: flash is memory-mapped (XIP) right now (we are NOT yet
    // in the interrupts-off critical section), so the existing flash block is
    // directly readable. Compare it byte-for-byte against the RAM block. If they
    // are identical, this block needs no erase/program - skip the whole
    // interrupts-off window for it. This is a PHYSICAL compare of the exact same
    // verbatim regions the commit copies (RAM phys offset vs flash phys offset);
    // it does NOT interpret the scrambled logical layout, so it cannot
    // reintroduce the Rev G logical dirty-tracking corruption. Worst case (whole
    // image changed) it behaves exactly as before, just with one 4 KB memcmp of
    // overhead per block - negligible vs a ~60-90 ms erase.
    const uint8_t *flash_blk = (const uint8_t *)(uintptr_t)(flash_addr + off);
    const uint8_t *ram_blk   = (const uint8_t *)(uintptr_t)(ram_addr + off);
    if (memcmp(flash_blk, ram_blk, prog_size) == 0) {
        ost_persist_phys_off = off + OST_FLASH_SECTOR;     // advance, no flash op
        return (ost_persist_phys_off < size);
    }

    ost_flash_commit_critical(cif, exx, ers, prg, flc, sxm,
                              flash_offs + off,
                              (const uint8_t *)(uintptr_t)(ram_addr + off),
                              OST_FLASH_SECTOR,    // erase this one 4 KB block
                              prog_size, clkdiv);

    ost_persist_phys_off = off + OST_FLASH_SECTOR;     // advance cursor
    return (ost_persist_phys_off < size);              // true => more blocks remain
}
#endif // OST_PERSIST_ON_IDLE

#endif // !OST_HOST_TEST

//  Byte feed - one received byte through the state machine.
//  Returns true if the byte still needs reprocessing (only when a 2-byte
//  opcode failed to match and the second byte may begin a new command).
static bool ost_feed_once(uint8_t b) {
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
    // Z-mode: bare commands (V, N, F, C, R, W) plus B-command tree
    // (BB silent, BRR -> 0x00) and S (silent swallow). Z-prefix path
    // retained but unused by HTS (trace confirmed bare framing).
    switch (ost.state) {
    case OST_IDLE:
        // HTS raw binary mode: after config W commands complete (w_completed_any),
        // consecutive non-command bytes (>= 2) in IDLE trigger raw mode. Every
        // byte is written sequentially to ROM starting from raw_offset = 0.
        if (ost.raw_mode) {
            // In raw mode: write every byte to ROM, ignore as command.
            // If offset exceeds ROM size the byte is dropped and raw mode
            // exits so the firmware can process post-upload queries (FF, etc.).
            if (ost.raw_offset < ostrich_active_rom_size()) {
                ostrich_rom_write_byte(ost.raw_offset, b);
            } else {
                ost.dropped_oob++;
                ost.raw_mode = false;           // past ROM end: exit raw mode
                ost.state    = OST_IDLE;
                ost_persist_mark(0u, 0u);       // arm flash commit
                return true;                    // reprocess byte as command
            }
            ost.raw_offset++;
            ost.raw_last_ms = board_millis();   // reset idle timer
            ost_persist_touch();
            return false;
        }
        DBG_POST_WRITE(b);                     // capture first bytes after trigger write
        if (b == 'Z') {
            ost.stray_count = 0;
            ost.state = OST_HTZ_SYNC;           // HTS: wait for command byte
        } else if (b == 'R') {
            ost.stray_count = 0;
            ost.htz_active = false;
            ost.param_len = 0;
            ost.state = OST_READ_PARAMS;
        } else if (b == 'W') {
            ost.stray_count = 0;
            ost.htz_active = false;
            ost.param_len = 0;
            ost.state = OST_WRITE_PARAMS;
        } else if (b == 'B') {
            ost.stray_count = 0;
            // Route B-prefixed commands through OST_SECOND so the full
            // B-command tree (BR/BRR/BE/BER/BES/BS, with n=0..8) is reachable.
            // OST_B_2ND below only handles BRR (read-back), which would
            // silently reject BR/BE/BS — and that broke mstrand's
            // `setbank 8` (BR 8) and TunerPro's pre-upload BR 8 setup.
            ost.lead = b;
            ost.state = OST_SECOND;
        } else if (b == 'S') {
            ost.stray_count = 0;
            ost.state = OST_S_PARAM;            // HTS silent command: swallow param+cksum
#ifdef OST_DT
        } else if (b == 'T') {
            ost.stray_count = 0;
            ost.trace_param_len = 0;
            ost.state = OST_TRACE_PARAMS;       // Trace: collect 12 param bytes
#endif
        } else if (ost_is_lead(b)) {
            ost.stray_count = 0;
            ost.lead = b;
            ost.state = OST_SECOND;
        } else {
            // Stray byte in IDLE: count consecutive non-command bytes.
            // When w_completed_any is true and the threshold (>= 2) is met,
            // enter raw mode (raw binary has started). A single stray between
            // W commands is just an inter-command gap and is skipped.
            DBG_STRAY_TICK();
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
            if (ost.w_completed_any) {
                ost.stray_count++;
                if (ost.stray_count >= 2) {
                    // 2+ consecutive non-command bytes: raw binary has started.
                    DBG_RAW_ENTERED();
                    ost.raw_mode    = true;
                    ost.raw_offset  = 0;
                    ost.raw_last_ms = board_millis();
                    // Write the saved first stray byte (from POST_W_CHECK)
                    if (ost.raw_offset < ostrich_active_rom_size()) {
                        ostrich_rom_write_byte(ost.raw_offset, ost.pending_raw_byte);
                    } else {
                        ost.dropped_oob++;
                    }
                    ost.raw_offset++;
                    // Write the current byte
                    if (ost.raw_offset < ostrich_active_rom_size()) {
                        ostrich_rom_write_byte(ost.raw_offset, b);
                    } else {
                        ost.dropped_oob++;
                    }
                    ost.raw_offset++;
                    ost.stray_count = 0;
                    ost_persist_mark(0u, 0u);   // HTS: arm flash commit on raw entry
                    ost_persist_touch();
                    return false;
                }
            }
#endif
        }
        return false;

    case OST_SECOND:
        // 'B' lead dispatches into the B-command tree (R/W bank, emulation
        // bank, persistent emulation bank + their read-backs). Otherwise the
        // standard 2-byte opcode table is tried.
        if (ost.lead == 'B') {
            if (b == 'R') { ost.state = OST_B_R_CMD; return false; }
            if (b == 'E') { ost.state = OST_B_E_CMD; return false; }
            if (b == 'S') { ost.state = OST_B_S_CMD; return false; }
            // 'B' followed by anything else (including 'B' itself, which
            // ost_try_opcode would have answered 0x00 for) is silently
            // dropped here. TunerPro RT does not send BB in the standard
            // (non-Z) protocol, so this is acceptable.
            ost.state = OST_IDLE;
            return false;
        }
        ost.state = OST_IDLE;
        if (ost_try_opcode(ost.lead, b)) return false;
        return true;

    case OST_HTZ_SYNC:
        // Got 'Z', now expecting command byte.
        // HTS uses Z-mode W for bulk ROM streaming: Z W count addr_hi addr_lo
        // then raw bytes (count * 256 bytes), single 'O' at end.
        ost.htz_cmd = b;
        ost.htz_active = true;
        if (htz_is_query_cmd(b)) {
            ost.state = OST_HTZ_QUERY_CKSUM;  // query cmd: 1 checksum byte follows
        } else if (b == 'R') {
            ost.param_len = 0;
            ost.state = OST_READ_PARAMS;      // R: 4 param bytes follow (count, ahi, alo, cksum)
        } else if (b == 'W') {
            ost.param_len = 0;
            ost.state = OST_HTZ_WRITE_STREAM; // Z-mode W: 3 header bytes then raw stream
        } else {
            // Unknown command after 'Z' — go back to waiting for 'Z'
            // instead of IDLE, to avoid false bare-command parsing from
            // random gap bytes that look like command letters.
            ost.state = OST_HTZ_AWAIT_Z;
        }
        return false;

    case OST_HTZ_QUERY_CKSUM:
        // Query command checksum byte
        htz_handle_query(ost.htz_cmd, b);
        ost.state = OST_IDLE;
        return false;

    case OST_B_2ND:
        // 2nd byte of a B-command. 'B','R' continues toward BRR; anything else
        // (including 'B','B') is silent, matching a real Ostrich.
        if (b == 'R') { ost.state = OST_B_3RD; }
        else          { ost.state = OST_IDLE; }
        return false;

    case OST_B_3RD:
        // 3rd byte. 'B','R','R' -> reply 0x00 (reply fires here, on the 3rd byte;
        // the trailing checksum byte that follows is swallowed, unvalidated).
        if (b == 'R') {
            ost_send_byte(0x00);
            ost.state = OST_B_CKSUM_Z;            // eat the next (checksum) byte
        } else {
            ost.state = OST_IDLE;               // B R <other> -> silent
        }
        return false;

    case OST_B_CKSUM_Z:
        // Swallow the checksum byte that follows BRR (value ignored).
        ost.state = OST_IDLE;
        return false;

    case OST_HTZ_WRITE_STREAM:
        // Z-mode W streaming: accumulate 3-byte header (count, addr_hi, addr_lo),
        // then write raw data sequentially to ROM.
        // Format: Z W count addr_hi addr_lo [count * 256 raw bytes]
        // After all bytes: reply 'O' (0x4F).
        {
            if (ost.param_len < 3) {
                // Collecting header bytes
                ost.params[ost.param_len++] = b;
                if (ost.param_len == 3) {
                    // Header complete — set up streaming.
                    // ZW header = count, MMSB, MSB. 19-bit start address
                    // (MMSB<<16)|(MSB<<8); LSB ticks up per 256-byte block.
                    const uint8_t  count    = ost.params[0];
                    const uint8_t  mmsb     = ost.params[1];
                    const uint8_t  msb      = ost.params[2];
                    const uint32_t rom_addr =
                        ((uint32_t)mmsb << 16) | ((uint32_t)msb << 8);

                    ost.write_offset    = rom_addr;
                    ost.htz_stream_remaining = (uint32_t)count * 256u;
                    ost_persist_touch();
                }
            } else {
                // Streaming raw data to ROM
                if (ost.htz_stream_remaining > 0) {
                    if (ost.write_offset < ostrich_active_rom_size()) {
                        ostrich_rom_write_byte(ost.write_offset, b);
                    } else {
                        ost.dropped_oob++;
                    }
                    ost.write_offset++;
                    ost.htz_stream_remaining--;
                    ost_persist_touch();   // HTS: keep debounce pushed back for full block

                    if (ost.htz_stream_remaining == 0) {
                        // All data received — send 'O' acknowledgment
                        ost_send_byte(OST_REPLY_STATUS_OK);
                        ost.state = OST_HTZ_AWAIT_Z;
                        ost.raw_last_ms = board_millis();
                        ost_persist_mark(0u, 0u);  // HTS: arm the debounced flash commit
                    }
                }
            }
        }
        return false;

    case OST_S_PARAM:
        // 'S' command: swallow the parameter byte (any value), no reply.
        ost.state = OST_S_CKSUM;
        return false;

    case OST_S_CKSUM:
        // Swallow the S command's checksum byte (any value), stay silent.
        ost.state = OST_IDLE;
        return false;

    case OST_READ_PARAMS:
        ost.params[ost.param_len++] = b;
        if (ost.param_len == OST_RW_PARAM_LEN) {
            if (ost.htz_active) {
                // HTS: params[0..2]=count,addrhi,addrlo; params[3]=checksum
                htz_handle_read(ost.params[0], ost.params[1], ost.params[2], ost.params[3]);
            } else {
                // TunerPro: params[0..2]=count,addrhi,addrlo; params[3]=checksum (ignored)
                ost_handle_read(ost.params[0], ost_decode_addr(ost.params[1], ost.params[2]));
            }
            ost.state = OST_IDLE;
        }
        return false;

    case OST_WRITE_PARAMS:
        ost.params[ost.param_len++] = b;
        if (ost.param_len == OST_W_HDR_LEN) {    // 3 bytes: count, addrhi, addrlo
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
            if (ost.w_completed_any) {
                ost.saved_write_offset = ost.write_offset;
            }
#endif
            DBG_FIRST_W(ost.params[0], ost.params[1], ost.params[2]);
            DBG_LOG_W(ost.params[1], ost.params[2], ost.params[0]);
            if (ost.htz_active) {
                htz_begin_write(ost.params[0], ost.params[1], ost.params[2]);
            } else {
                ost_begin_write(ost.params[0], ost_decode_addr(ost.params[1], ost.params[2]));
            }
            ost.state = OST_WRITE_DATA;
        }
        return false;

    case OST_WRITE_DATA:
        ost_write_payload_byte(b);
        return false;

    case OST_POST_W_CHECK:
        // A W command just completed when w_completed_any was already true.
        // If the next byte is a command, reprocess it. If it's a non-command
        // byte (inter-W gap or start of raw binary), save it and return to
        // IDLE. The IDLE stray threshold determines when raw mode starts.
        {
            const bool is_cmd = (b == 'W' || b == 'R' || b == 'B' ||
                                 b == 'S' || b == 'Z' || ost_is_lead(b));
            DBG_POST_W_CHECK(b, is_cmd);
            if (is_cmd) {
                ost.state = OST_IDLE;
                return true;                    // reprocess as new command
            }
            // Non-command byte: save and arm raw mode detection.
            // Don't enter raw mode yet — IDLE counts consecutive strays
            // and enters raw mode only when the threshold is reached.
            ost.pending_raw_byte = b;
            ost.stray_count      = 1;
            ost.state            = OST_IDLE;
        }
        return false;

    case OST_HTZ_AWAIT_Z:
        // After a Z-mode W block completes, HTS sends gap bytes before the next
        // block. These gaps contain random data that may accidentally match
        // command letters ('W','R','Z','S',etc), causing false command parsing
        // that desynchronizes the stream. Only accept 'Z' to begin the next
        // Z-mode command; ignore everything else.
        if (b == 'Z') {
            DBG_Z_AWAIT_RESUME();
            ost.state = OST_HTZ_SYNC;
        }
        return false;

    // ---- B-command tree (TunerPro standard Ostrich mode) -----------------
    // Format:  'B', R|E|S, n|letter, [CS]
    //   B R n CS  -> set R/W bank (volatile), reply 'O'  (n=0..8)
    //   B R R CS  -> read-back R/W bank, reply n + CS
    //   B E n CS  -> set emulation bank (volatile), reply 'O'  (n=0..8)
    //   B E R CS  -> read-back volatile emulation bank, reply n + CS
    //   B E S CS  -> read-back persistent emulation bank, reply n + CS
    //   B S n CS  -> set persistent emulation bank, reply 'O'  (n=0..8)
    // The Z-mode IDLE handler routes 'B' to OST_SECOND, which dispatches
    // 'B'+'R'/'E'/'S' to these states. The OSTRICH_Z mode previously
    // only had an OST_B_2ND/OST_B_3RD pair that handled BRR (read-back)
    // only — BR/BE/BS were silently dropped, which broke mstrand's
    // `setbank 8` and TunerPro's pre-upload BR 8 setup.
    case OST_B_R_CMD:
        if (b == 'R') {
            ost_send_byte(ost.rw_bank);
            ost.state = OST_B_CKSUM;
        } else if (b <= 8) {
            ost.rw_bank = b;
            ost_send_byte(OST_REPLY_STATUS_OK);   // 'O'
            ost.state = OST_B_CKSUM;
        } else {
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_E_CMD:
        if (b == 'R') {
            ost_send_byte(ost.emulation_bank);
            ost.state = OST_B_CKSUM;
        } else if (b == 'S') {
            ost_send_byte(ost.emulation_bank_pers);
            ost.state = OST_B_CKSUM;
        } else if (b <= 8) {
            ost.emulation_bank = (uint8_t)b;
            ost.emulation_bank_pers = (uint8_t)b;
            ost_send_byte(OST_REPLY_STATUS_OK);
            ost.state = OST_B_CKSUM;
        } else {
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_S_CMD:
        if (b <= 8) {
            ost.emulation_bank = (uint8_t)b;
            ost.emulation_bank_pers = (uint8_t)b;
            ost_send_byte(OST_REPLY_STATUS_OK);
            ost.state = OST_B_CKSUM;
        } else {
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_CKSUM:
        // Swallow the trailing checksum byte of any B command.
        ost.state = OST_IDLE;
        return false;

#ifdef OST_DT
    case OST_TRACE_PARAMS:
        // Collect T command parameters: x1,x2,x3,y1,y2,sMMSB,sMSB,sLSB,eMMSB,eMSB,eLSB,CS (12 bytes)
        ost.trace_params[ost.trace_param_len++] = b;
        if (ost.trace_param_len >= 12) {
            if (ost_trace_report()) {
                ost.state = OST_IDLE;
            }
            // else: streaming — stay in TRACE_PARAMS for the next poll
        }
        return false;
#endif

    default:
        return false;
    }
#else
    // TunerPro Ostrich mode: bare commands, no 'Z' sync
    switch (ost.state) {
    case OST_IDLE:
        if (b == 'R') { ost.param_len = 0; ost.state = OST_READ_PARAMS; }
        else if (b == 'W') { ost.param_len = 0; ost.state = OST_WRITE_PARAMS; }
#ifdef OST_DT
        else if (b == 'T') { ost.trace_param_len = 0; ost.state = OST_TRACE_PARAMS; }
#endif
        else if (ost_is_lead(b)) { ost.lead = b; ost.state = OST_SECOND; }
        else { DBG_STRAY_TICK(); }   // stray byte, ignore (diag: count it)
        return false;

    case OST_SECOND:
        // 'B' lead dispatches into the B-command tree (R/W bank, emulation
        // bank, persistent emulation bank + their read-backs). Otherwise the
        // standard 2-byte opcode table is tried.
        if (ost.lead == 'B') {
            if (b == 'R') { ost.state = OST_B_R_CMD; return false; }
            if (b == 'E') { ost.state = OST_B_E_CMD; return false; }
            if (b == 'S') { ost.state = OST_B_S_CMD; return false; }
            // 'B' followed by anything else (including 'B' itself) is
            // silently dropped here, matching a real Ostrich.
            ost.state = OST_IDLE;
            return false;
        }
        ost.state = OST_IDLE;
        if (ost_try_opcode(ost.lead, b)) return false;
        // Pair didn't match. The second byte might start a new command, so
        // ask the caller to reprocess it from IDLE.
        return true;

    // ---- B-command tree (TunerPro standard Ostrich mode) -----------------
    // Format:  'B', R|E|S, n|letter, [CS]
    //   B R n CS  -> set R/W bank (volatile), reply 'O'  (n=0..7)
    //   B R R CS  -> read-back R/W bank, reply n + CS
    //   B E n CS  -> set emulation bank (volatile), reply 'O'  (n=0..7 or 8)
    //   B E R CS  -> read-back volatile emulation bank, reply n + CS
    //   B E S CS  -> read-back persistent emulation bank, reply n + CS
    //   B S n CS  -> set persistent emulation bank, reply 'O'  (n=0..7 or 8)
    // We follow the existing convention of accepting any trailing byte as
    // the checksum (no validation) — matches how the R/W headers already
    // ignore their cksum byte.
    case OST_B_R_CMD:
        // 3rd byte of B R <n|R>
        if (b == 'R') {
            // Read-back: reply with current R/W bank + checksum byte.
            // Per the Moates protocol doc, "nj" = single byte n. Real
            // Ostrich sends only the value byte; the trailing CS the host
            // is expecting belongs to the request, not the response.
            ost_send_byte(ost.rw_bank);
            ost.state = OST_B_CKSUM;
        } else if (b <= 8) {
            // Moates spec: n is 0-8. n=8 is the "full 4 Mbit" mode that makes
            // the MMSB field of bulk ZW/ZR commands effective and is required
            // for 128 KB+ bin uploads. Rejecting n=8 here caused both mstrand's
            // `setbank 8` and TunerPro's pre-upload setup to silently fail —
            // leaving the device in R/W bank 0 (64 KB window) and producing
            // the "Bin is larger than emulation RAM" error on 128 KB bins.
            ost.rw_bank = b;
            ost_send_byte(OST_REPLY_STATUS_OK);   // 'O'
            ost.state = OST_B_CKSUM;
        } else {
            // Out-of-range n (> 8) — silently reject
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_E_CMD:
        // 3rd byte of B E <n|R|S>
        if (b == 'R') {
            ost_send_byte(ost.emulation_bank);
            ost.state = OST_B_CKSUM;
        } else if (b == 'S') {
            ost_send_byte(ost.emulation_bank_pers);
            ost.state = OST_B_CKSUM;
        } else if (b <= 8) {
            ost.emulation_bank = (uint8_t)b;
            ost.emulation_bank_pers = (uint8_t)b;  // no real persistence
            ost_send_byte(OST_REPLY_STATUS_OK);
            ost.state = OST_B_CKSUM;
        } else {
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_S_CMD:
        // 3rd byte of B S <n>
        if (b <= 8) {
            ost.emulation_bank = (uint8_t)b;
            ost.emulation_bank_pers = (uint8_t)b;
            ost_send_byte(OST_REPLY_STATUS_OK);
            ost.state = OST_B_CKSUM;
        } else {
            ost.state = OST_IDLE;
        }
        return false;

    case OST_B_CKSUM:
        // Swallow the trailing checksum byte of any B command.
        ost.state = OST_IDLE;
        return false;

#ifdef OST_DT
    case OST_TRACE_PARAMS:
        // Collect T command parameters: x1,x2,x3,y1,y2,sMMSB,sMSB,sLSB,eMMSB,eMSB,eLSB,CS (12 bytes)
        ost.trace_params[ost.trace_param_len++] = b;
        if (ost.trace_param_len >= 12) {
            if (ost_trace_report()) {
                ost.state = OST_IDLE;
            }
        }
        return false;
#endif

    case OST_READ_PARAMS:
        ost.params[ost.param_len++] = b;
        if (ost.param_len == OST_RW_PARAM_LEN) {
            ost_handle_read(ost.params[0],
                            ost_decode_addr(ost.params[1], ost.params[2]));
            ost.state = OST_IDLE;
        }
        return false;

    case OST_WRITE_PARAMS:
        ost.params[ost.param_len++] = b;
        if (ost.param_len == OST_W_HDR_LEN) {    // 3 bytes: count, addrhi, addrlo
            DBG_FIRST_W(ost.params[0], ost.params[1], ost.params[2]);
            ost_begin_write(ost.params[0],
                            ost_decode_addr(ost.params[1], ost.params[2]));
        }
        return false;

    case OST_WRITE_DATA:
        ost_write_payload_byte(b);
        return false;

    default:
        return false;
    }
#endif
}

static void ost_feed(uint8_t b) {
    DBG_RX_TICK();                       // diag: total bytes seen by the parser
    // A 2-byte opcode that doesn't match (OST_SECOND) returns its second byte to
    // be reprocessed, since that byte may begin a new command. Reprocessing ALWAYS
    // targets IDLE, and IDLE never asks for a reprocess, so this resolves in at
    // most two passes; the iteration cap is a belt-and-braces guard that makes
    // non-termination structurally impossible.
    for (int i = 0; i < 3 && ost_feed_once(b); i++) { }
}

//  Public API

void usb_ostrich_init(void) {
    memset(&ost, 0, sizeof ost);
    ost.state = OST_IDLE;
#if OST_DBG_FIRSTW
    memset(&ost_dbg, 0, sizeof ost_dbg);
    ost_dbg.cap_idx = 0xFF;          // capture disabled until trigger fires
    ost_dbg.cap_trigger = 11;        // capture after 11th W completes (after config phase)
#endif
#ifndef OST_HOST_TEST
    ost_engine_init();
#endif
}

void usb_ostrich_task(void) {
    // HTS raw mode idle timeout: exit raw mode after OST_RAW_IDLE_MS with no
    // raw bytes, so the parser can handle post-upload queries (FF, VV, etc.).
    // Each raw byte stamps raw_last_ms = board_millis().
    //
    // The persist debounce is intentionally touched during raw mode writes
    // to prevent the flash auto-commit from firing mid-upload.
#if PROTOCOL_MODE == PROTO_OSTRICH_Z
    if (ost.raw_mode) {
        if ((uint32_t)(board_millis() - ost.raw_last_ms) > OST_RAW_IDLE_MS) {
            ost.raw_mode = false;
        }
    }
    // Z-mode await timeout: if we're waiting for the next 'Z' sync after a
    // completed block and HTS doesn't send one within OST_RAW_IDLE_MS, fall
    // back to IDLE so post-upload queries (FF, VV, etc.) can be handled.
    if (ost.state == OST_HTZ_AWAIT_Z) {
        if ((uint32_t)(board_millis() - ost.raw_last_ms) > OST_RAW_IDLE_MS) {
            DBG_Z_AWAIT_TIMEOUT();
            ost.state = OST_IDLE;
        }
    }
#endif
    while (tud_cdc_n_available(OST_CDC_ITF)) {
        int32_t c = tud_cdc_n_read_char(OST_CDC_ITF);
        if (c < 0) break;
#ifdef OST_TRACE_RX
        // Diagnostic: mirror every byte received on the Ostrich port out to the
        // Trace CDC (instance 1) so a host-side logger can capture exactly what
        // the host sends during connect. Off unless built
        // with -DOST_TRACE_RX. Best-effort: if the Trace FIFO is full we drop the
        // copy rather than stall the Ostrich path. Requires the Trace CDC to be
        // present (i.e. not UART_MODE_DISABLED).
#if !UART_CDC_PRESENT
#error "OST_TRACE_RX needs the Trace CDC present - do not use with UART_MODE_DISABLED"
#endif
        if (tud_cdc_n_write_available(1) > 0) {
            uint8_t tb = (uint8_t)c;
            tud_cdc_n_write(1, &tb, 1);
            tud_cdc_n_write_flush(1);
        }
#endif
        ost_feed((uint8_t)c);
    }
    ost_persist_task();                          // debounced flash auto-commit
}
