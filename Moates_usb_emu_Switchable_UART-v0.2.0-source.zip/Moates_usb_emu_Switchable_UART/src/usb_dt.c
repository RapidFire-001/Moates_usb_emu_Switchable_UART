// Copyright (C) 2026 — MIT License
//
// One ROM USB system plugin: Data Tracing (DT) implementation.
// Captures address bus activity via PIO address monitor into a ring buffer.
// Enabled with DT=1 build flag. Works alongside any UART_MODE.
// For 27C256 and 27C512 EPROMs only (28-pin, <=64KB).

#include "tusb_config.h"

#ifdef OST_DT

#include "usb_dt.h"
#include "usb_plugin.h"
#include <string.h>

// Ring buffer: 4 entries × 4 bytes = 16 bytes .bss.
#define RING_ENTRIES_LOG2   2
#define RING_ENTRIES_NUM    (1u << RING_ENTRIES_LOG2)

// Ring buffer for captured addresses from PIO, written by DMA.
// Must be aligned to its size and be a power of 2 in length.
static uint32_t __attribute__((aligned(RING_ENTRIES_NUM * 4)))
    ring_buf[RING_ENTRIES_NUM];

// Host-facing queue of already-demangled logical addresses. usb_dt_task() is
// the ONLY drainer of ring_buf/read_ptr (hardware side); usb_dt_get_capture()
// is the ONLY reader of this queue (host/'T'-command side). Keeping these two
// consumers separate avoids them racing over a single read_ptr into ring_buf
// (both draining the same hardware ring independently silently dropped hits
// for whichever consumer lost the race). Same depth as ring_buf; a T command
// not polling often enough drops the oldest queued hit, same failure mode a
// too-slow poll already has against the hardware ring.
static uint32_t host_queue[RING_ENTRIES_NUM];
static uint32_t host_queue_head;   // next slot usb_dt_task() writes
static uint32_t host_queue_tail;   // next slot usb_dt_get_capture() reads
static uint32_t host_queue_count;  // entries currently queued (0..RING_ENTRIES_NUM)

// ORA API function pointers (resolved once at init)
static ora_setup_address_monitor_fn_t   setup_address_monitor;
static ora_start_address_monitor_fn_t   start_address_monitor;
static ora_get_address_monitor_ring_write_pos_fn_t get_ring_write_pos;
static ora_demangle_addr_fn_t           demangle_addr;

// Ring buffer read pointer (local copy, updated by main loop)
static volatile uint32_t *read_ptr;

// Initialization state
static bool dt_initialized = false;

// Total addresses captured since init
static uint32_t dt_capture_count;

void usb_dt_init(void) {
    // No-op: real init happens in usb_dt_init_with_lookup()
}

void usb_dt_init_with_lookup(ora_lookup_fn_t ora_lookup_fn) {
    if (dt_initialized) return;

    ora_log_fn_t log = ora_lookup_fn(ORA_ID_LOG);
    setup_address_monitor = ora_lookup_fn(ORA_ID_SETUP_ADDRESS_MONITOR);
    start_address_monitor = ora_lookup_fn(ORA_ID_START_ADDRESS_MONITOR);
    get_ring_write_pos = ora_lookup_fn(ORA_ID_GET_ADDRESS_MONITOR_RING_WRITE_POS);
    demangle_addr = ora_lookup_fn(ORA_ID_DEMANGLE_ADDR);

    if (!log || !setup_address_monitor || !start_address_monitor ||
        !get_ring_write_pos || !demangle_addr) {
        return;
    }

    log("DT: init (ring=%d entries)", RING_ENTRIES_NUM);

    // Validate chip type — DT only supports 27C256/27C512
    const sdrr_runtime_info_t *rt = ora_lookup_fn(ORA_ID_GET_RUNTIME_INFO)
                                    ? ((ora_get_runtime_info_fn_t)ora_lookup_fn(ORA_ID_GET_RUNTIME_INFO))()
                                    : NULL;
    if (rt) {
        uint8_t rom_type = rt->piorom_config.rom_type;
        if (rom_type != CHIP_TYPE_27256 && rom_type != CHIP_TYPE_27512) {
            log("DT: unsupported chip type %u, aborting", rom_type);
            return;
        }
        log("DT: rom_type=%u num_addr_pins=%u", rom_type,
            rt->piorom_config.num_addr_pins);
    }

    // Set up address monitor in OBSERVE mode (passive, no control pins)
    if (setup_address_monitor(ring_buf, RING_ENTRIES_LOG2,
                              ORA_MONITOR_MODE_OBSERVE, 32, NULL) != ORA_RESULT_OK) {
        log("DT: setup failed");
        return;
    }

    start_address_monitor();

    // Get the ring buffer write position pointer
    volatile uint32_t * volatile *ring_write_pos = get_ring_write_pos();

    // Initialize read pointer to current write position (discard initial captures)
    read_ptr = *ring_write_pos;
    dt_capture_count = 0;
    host_queue_head = 0;
    host_queue_tail = 0;
    host_queue_count = 0;

    dt_initialized = true;
    log("DT: monitor started");
}

void usb_dt_task(void) {
    if (!dt_initialized) return;

    // Sole consumer of the hardware ring — see host_queue comment above.
    volatile uint32_t * volatile *ring_write_pos = get_ring_write_pos();

    while (read_ptr != *ring_write_pos) {
        uint32_t phys_addr = *read_ptr;

        // Convert to logical address, count, and queue for the host side.
        uint32_t logical_addr;
        if (demangle_addr(phys_addr, &logical_addr, 1) == ORA_RESULT_OK) {
            dt_capture_count++;
            if (host_queue_count < RING_ENTRIES_NUM) {
                host_queue[host_queue_head] = logical_addr;
                host_queue_head = (host_queue_head + 1u) & (RING_ENTRIES_NUM - 1u);
                host_queue_count++;
            }
            // else: host queue full, host isn't polling fast enough — drop,
            // same as an unread hardware-ring entry would be.
        }

        // Advance read pointer with wrap
        if (++read_ptr >= ring_buf + RING_ENTRIES_NUM) {
            read_ptr = ring_buf;
        }
    }
}

bool usb_dt_get_capture(uint32_t *logical_addr_out) {
    if (!dt_initialized || host_queue_count == 0) return false;

    *logical_addr_out = host_queue[host_queue_tail];
    host_queue_tail = (host_queue_tail + 1u) & (RING_ENTRIES_NUM - 1u);
    host_queue_count--;
    return true;
}

uint32_t usb_dt_get_capture_count(void) {
    return dt_capture_count;
}

#endif // OST_DT
