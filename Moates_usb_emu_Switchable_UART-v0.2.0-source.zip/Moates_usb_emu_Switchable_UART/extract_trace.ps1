$lines = Get-Content 'D:\OneROM\CODING\python\trace_COM50_20260619-100233.txt'
foreach ($line in $lines) {
    if ($line -match '^\[' -and $line.Length -lt 300) {
        Write-Output $line
    }
}
