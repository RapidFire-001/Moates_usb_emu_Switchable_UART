#!/usr/bin/env bash
#
# build_32.sh - build the usb_emu_system_plugin for Fire 32 A (RP2354B)
#
# Fire 32 A hardwired UART pins (RP2350 F11 mapping):
#   GPIO 38 = UART TX (PCB pin 47, SEL_C, F11 = UART1 TX)
#   GPIO 39 = UART RX (PCB pin 48, SEL_D, F11 = UART1 RX)
#
# Usage:
#   ./build_32.sh NORMAL                # 38400 baud, PROTO_OSTRICH
#   ./build_32.sh ALDL_808              # 8192 baud, no inversion, PROTO_OSTRICH
#   ./build_32.sh ALDL_808_TX_Inv       # 8192 baud, TX line inverted, PROTO_OSTRICH
#   ./build_32.sh ALDL_808_RX_Inv       # 8192 baud, RX line inverted, PROTO_OSTRICH
#   ./build_32.sh ALDL_808_TXRX_Inv     # 8192 baud, TX and RX inverted, PROTO_OSTRICH
#   ./build_32.sh OSTRICH_Z             # 38400 baud, PROTO_OSTRICH_Z (Z-prefixed + checksum)
#   ./build_32.sh DISABLED              # no UART bridge
#   ./build_32.sh NORMAL DT             # NORMAL + address bus monitoring
#   ./build_32.sh OSTRICH_Z DT          # OSTRICH_Z + address bus monitoring
#   ./build_32.sh all                   # build all modes (with and without DT)
#
# Each mode is built with `make clean && make UART_MODE=... [UART_INVERT_*=1]
# [PROTOCOL_MODE=...] [DT=1]`, then the output .bin is copied to ./output/
# before the next mode starts, so all outputs are preserved.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILDS_DIR="${SCRIPT_DIR}/output"

# Fire 32 A: GPIO 38 = TX (SEL_C, F11=UART1 TX), GPIO 39 = RX (SEL_D, F11=UART1 RX)
UART_TX_PIN_DEFAULT=38
UART_RX_PIN_DEFAULT=39

# Allow override from environment
TX_PIN="${UART_TX_PIN:-$UART_TX_PIN_DEFAULT}"
RX_PIN="${UART_RX_PIN:-$UART_RX_PIN_DEFAULT}"

MODES=(NORMAL ALDL_808 ALDL_808_TX_Inv ALDL_808_RX_Inv ALDL_808_TXRX_Inv OSTRICH_Z DISABLED)

build_mode() {
    local mode="$1"
    local use_dt="$2"
    local make_args=()
    local makefile_stem="$mode"
    local out_name="$mode"

    case "$mode" in
        NORMAL)
            make_args=()
            makefile_stem="NORMAL"
            ;;
        ALDL_808)
            make_args=("UART_MODE=UART_MODE_ALDL_808")
            makefile_stem="ALDL_808"
            ;;
        ALDL_808_TX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_TX=1")
            makefile_stem="ALDL_808_TX_Inv"
            ;;
        ALDL_808_RX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_RX=1")
            makefile_stem="ALDL_808_RX_Inv"
            ;;
        ALDL_808_TXRX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_TX=1" "UART_INVERT_RX=1")
            makefile_stem="ALDL_808_TXRX_Inv"
            ;;
        OSTRICH_Z)
            make_args=("UART_MODE=UART_MODE_HTS" "PROTOCOL_MODE=PROTO_OSTRICH_Z")
            makefile_stem="HTS"
            out_name="OSTRICH_Z"
            ;;
        DISABLED)
            make_args=("UART_MODE=UART_MODE_DISABLED")
            makefile_stem="DISABLED"
            ;;
        *)
            echo "Unknown mode: $mode" >&2
            return 1
            ;;
    esac

    # Append DT flag if requested
    if [ "$use_dt" = "1" ]; then
        make_args+=("DT=1")
        out_name="${out_name}_DT"
        makefile_stem="${makefile_stem}_DT"
    fi

    echo "=========================================="
    echo "Building mode: $mode (Fire 32 A: TX=GPIO$TX_PIN, RX=GPIO$RX_PIN)"
    if [ ${#make_args[@]} -gt 0 ]; then
        echo "  make args: ${make_args[*]}"
    fi
    echo "=========================================="
    cd "$SCRIPT_DIR"
    make clean >/dev/null
    make all \
        "UART_TX_PIN=$TX_PIN" \
        "UART_RX_PIN=$RX_PIN" \
        "${make_args[@]}"

    local bin_file="${SCRIPT_DIR}/build/usb_emu_system_plugin_${makefile_stem}.bin"
    if [ ! -f "$bin_file" ]; then
        echo "ERROR: expected output not found: $bin_file" >&2
        return 1
    fi

    mkdir -p "$BUILDS_DIR"
    if [ "$use_dt" = "1" ]; then
        # DT variants are board-agnostic (no _32 suffix)
        cp "$bin_file" "${BUILDS_DIR}/usb_emu_system_plugin_${out_name}.bin"
        echo "Copied to: ${BUILDS_DIR}/usb_emu_system_plugin_${out_name}.bin"
    else
        cp "$bin_file" "${BUILDS_DIR}/usb_emu_system_plugin_${out_name}_32.bin"
        echo "Copied to: ${BUILDS_DIR}/usb_emu_system_plugin_${out_name}_32.bin"
    fi
}

usage() {
    echo "Usage: $0 [MODE] [DT] | all [DT]"
    echo ""
    echo "Fire 32 A (RP2354B) build — pins GPIO38=TX, GPIO39=RX (RP2350 F11) hardwired."
    echo ""
    echo "Modes:"
    echo "  NORMAL              38400 baud, PROTO_OSTRICH (default)"
    echo "  ALDL_808            8192 baud, no inversion, PROTO_OSTRICH"
    echo "  ALDL_808_TX_Inv     8192 baud, TX line inverted, PROTO_OSTRICH"
    echo "  ALDL_808_RX_Inv     8192 baud, RX line inverted, PROTO_OSTRICH"
    echo "  ALDL_808_TXRX_Inv   8192 baud, TX and RX inverted, PROTO_OSTRICH"
    echo "  OSTRICH_Z           38400 baud, PROTO_OSTRICH_Z (Z-prefixed + checksum)"
    echo "  DISABLED            no UART bridge"
    echo "  all                 build all modes (with and without DT)"
    echo ""
    echo "Flags:"
    echo "  DT                  enable address bus monitoring (27C256/27C512 only)"
    echo ""
    echo "Examples:"
    echo "  $0 NORMAL           # NORMAL mode without DT"
    echo "  $0 NORMAL DT        # NORMAL mode with DT"
    echo "  $0 OSTRICH_Z DT     # OSTRICH_Z mode with DT"
    echo "  $0 all              # all modes (with and without DT, 14 total)"
    echo ""
    echo "Override pins: UART_TX_PIN=38 UART_RX_PIN=39 $0 ALDL_808"
    exit 1
}

if [ $# -eq 0 ]; then
    usage
fi

# Parse arguments
MODE=""
DT_FLAG="0"
for arg in "$@"; do
    case "$arg" in
        -h|--help|help)
            usage
            ;;
        DT)
            DT_FLAG="1"
            ;;
        all)
            MODE="all"
            ;;
        *)
            if [ -z "$MODE" ]; then
                MODE="$arg"
            else
                echo "Unknown argument: $arg" >&2
                usage
            fi
            ;;
    esac
done

if [ -z "$MODE" ]; then
    usage
fi

if [ "$MODE" = "all" ]; then
    # Build all modes without DT
    for m in "${MODES[@]}"; do
        build_mode "$m" "0"
    done
    # Build all modes with DT
    for m in "${MODES[@]}"; do
        build_mode "$m" "1"
    done
    echo ""
    echo "All modes built. Outputs in $BUILDS_DIR:"
    ls -la "$BUILDS_DIR"
else
    valid=0
    for m in "${MODES[@]}"; do
        if [ "$MODE" = "$m" ]; then
            valid=1
            break
        fi
    done
    if [ $valid -eq 0 ]; then
        echo "Unknown mode: $MODE" >&2
        usage
    fi
    build_mode "$MODE" "$DT_FLAG"
fi
