# Changelog

## [0.2.0] - 2026-07-12

REV J0.2: Add Data Tracing (DT) build flag for address bus monitoring.

- **New build flag: `DT=1`** (`Makefile`, `tusb_config.h`):
  - DT is a build flag (like `OST_TRACE_RX`), not a UART_MODE.
  - Enables PIO address bus monitoring alongside any UART mode.
  - Valid combinations:
    - `UART_MODE=NORMAL DT=1` — UART bridge + address monitoring
    - `UART_MODE=DISABLED DT=1` — no CDC 1 + address monitoring
    - `UART_MODE=UART_MODE_HTS DT=1` — HTS/Ostrich_Z + address monitoring
    - `UART_MODE=NORMAL` — current behavior, no address monitoring
  - For 27C256 and 27C512 EPROMs only (28-pin, <=64KB).

- **Wire format** (`usb_dt.c:11-13`):
  - Each captured address is stored in a ring buffer (16 entries × 4 bytes = 64B .bss).
  - Addresses are captured by PIO address monitor (PIO0 SM0/SM1 + DMA channel 2).
  - Captured addresses can be retrieved via `usb_dt_get_capture()` for future Ostrich command extension.

- **Ostrich protocol extension: `'T'` trace command** (`usb_ostrich.c`):
  - Implements the Moates Ostrich 2.0 trace protocol (v19 spec).
  - Command: `'T'+x1+x2+x3+y1+y2+sMMSB+sMSB+sLSB+eMMSB+eMSB+eLSB+CS`
  - Response: `'O'+MMSB1+MSB1+LSB+...+MMSBy+MSBy+LSBy+'O'`
  - x1 bitmask: B0=streaming, B1=windowed, B2=nonredundant, B6-B7=addr bytes (0=3, 1=1, 2=2)
  - y1 = number of hits to buffer per packet
  - Gated on `OST_DT` — zero impact on non-DT builds.
  - Works on same COM port as Ostrich emulation (CDC 0).

- **Build support**:
  - `Makefile`: Added `DT=1` flag passthrough and `_DT` suffix to output filenames.
  - `build_32.sh`: `./build_32.sh all` builds all 14 variants (7 modes × 2 DT options).
    DT variants are board-agnostic (no `_32` suffix).
  - Build with: `make DT=1` or `make UART_MODE=UART_MODE_HTS DT=1`

- **Files added/modified**:
  - `include/usb_dt.h`: New header for DT mode interface.
  - `src/usb_dt.c`: New implementation for address bus monitoring.
  - `include/tusb_config.h`: Removed `UART_MODE_DT` (DT is now a flag).
  - `Makefile`: Version bump to 0.2.0 (MINOR_VERSION=2, PATCH_VERSION=0), added DT flag.
  - `build_32.sh`: Restructured for DT as a flag, not a mode.

## [0.1.18] - 2026-06-28

Fire 32 A follow-ups: bit-reverse fix, persist on, single-CDC DISABLED,
FIFO size knobs.

- **Fire 32 A Ostrich bit-reverse fix** (`usb_rom.c:287`):
  - **Bug**: TunerPro reads produced a 7-bit periodic pattern
    (every 128 bytes shifted, then rotated) on the Fire 32 A pinout.
    mstrand verified, but TunerPro read 0% because the 7-bit pattern
    is not a valid 27C010 image. EPROM programmer reads were unaffected
    (the EPROM address lines and the PIO address mapping matched).
  - **Root cause**: `app_logical_addr_to_offset` used
    `max_gpio - addr_gpio[ii]` to compute the bit position for the
    address GPIO. The PIO's `IN_BASE` already does the bit-reverse
    (bit 0 = max_gpio, bit 18 = min_gpio), so the host-to-PIO offset
    should have been `addr_gpio[ii] - min_addr_pin`. The two are
    equivalent only when the address GPIOs are contiguous from min to
    max (true for the 16-pin Fire 28 layout, false for the 19-pin
    Fire 32 A layout which uses pins 16-34 with `addr2[0]=16`).
  - **Fix**: one-character-class change to `addr_gpio[ii] - min_addr_pin`.
  - **Verified**: TunerPro 27C010 read matches `27C010.BIN` byte-for-byte
    on Fire 32 A. mstrand also 100%.

- **Persist enabled by default** (`usb_ostrich.c:215`):
  - The `OST_PERSIST_ON_IDLE` source default is 1 (ON). Previously
    the Fire 32 A build hardcoded 0 to fit the 2 KB plugin DATA_LIMIT
    — the persist code (chunked 4 KB commit, skip-if-unchanged,
    function pointer indirection) was too big. With the FIFO shrink
    below it now fits, so persist is unconditionally ON.
  - Without persist, every power cycle drops the uploaded image back
    to the cold flash preload — the Ostrich emulation is useless on
    the bench without it.

- **CDC FIFO shrink to fit persist** (`tusb_config.h:169-189`):
  - TinyUSB CDC FIFOs are per-instance; with 2 CDCs (Ostrich + Trace)
    every byte costs x2 SRAM. The Fire 28 reference build used 64 B
    per direction. Fire 32 A shrinks where it can:
    - CDC RX  = 64 B (must be >= USB FS bulk max packet of 64 B,
      or host bulk OUTs truncate)
    - CDC TX  = 32 B (peripheral pushes in chunks, host buffers)
    - Vendor  = 32 B per direction (picobootx commands/responses are
      small)
  - Tunable via `OST_CDC_RX_FS` make variable (default 64; raise to
    128 for high-throughput hosts; never below 64).
  - **Verified**: `make all OST_PERSIST_ON_IDLE=1` builds with `.bss`
    at 1672 B / 2048 B (200 B headroom).

- **Layout diagnostic gated on `OST_DEBUG_LAYOUT`** (`usb_ostrich.c:646-673`):
  - The 192 B `ost_dbg_buf` and ~250 B of `append_*` helpers used to
    dump the PIO pin layout before the first Ostrich reply are now
    behind `OST_DEBUG_LAYOUT` (default 0). Enable with
    `make all OST_DEBUG_LAYOUT=1` for future debugging. Was the
    diagnostic that found the bit-reverse bug above.
  - Drops `.bss` by 200 B, contributing to the headroom above.

- **`DISABLED` mode actually drops CDC2** (`tusb_config.h:84`):
  - **Bug**: `UART_MODE_DISABLED` builds were meant to enumerate with
    one CDC only. They didn't — a leftover `#if PROTOCOL_MODE ==
    PROTO_HTS` override referred to a symbol that was renamed to
    `PROTO_OSTRICH_Z` in 0.1.17. Undefined macros in `#if` are
    treated as 0, so the check was always true and forced
    `UART_CDC_PRESENT = 1` / `CFG_TUD_CDC = 2` regardless of
    `UART_MODE`. The descriptor hid CDC2 correctly, but the runtime
    kept allocating 360 B for two CDC instances and the UART bridge
    code stayed compiled in.
  - **Fix**: remove the dead HTS override. The remaining
    `UART_CDC_PRESENT = (UART_MODE != UART_MODE_DISABLED)` is the
    single source of truth.
  - **Verified per mode** (Fire 32 A, persist on, layout debug off):
    - NORMAL, ALDL_808, ALDL_808_{TX,RX,TXRX}_Inv: `.bss=1672`,
      `_cdcd_itf=360 B` (2 CDCs) — **unchanged**
    - DISABLED: `.bss=1408`, `_cdcd_itf=180 B` (1 CDC) — **fixed**
      (saved 264 B `.bss`, 868 B plugin `.bin`)
  - The main ALDL_808 firmware image
    (`builds/fw/onerom_fire-32-a_27C010-ostrich.bin`) is byte-identical
    to 0.1.17 — the fix is DISABLED-only.

- **Build script** (`build_32.sh`, `build_fire32a_aldl.sh`):
  - `build_32.sh`: drops `OSTRICH_Z` mode (exceeds DATA_LIMIT on
    Fire 32 A). 6 modes remain: NORMAL, ALDL_808, ALDL_808_{TX,RX,
    TXRX}_Inv, DISABLED.
  - `build_fire32a_aldl.sh`: top-level wrapper that auto-builds the
    system plugin (Step 0) and all 6 `_32` variants (Step 3b), then
    packages them with the OneROM CLI into the final `onerom_fire-32-
    a_27C010-ostrich.bin`.

- **Makefile passthroughs**: `OST_CDC_RX_FS`, `OST_DEBUG_LAYOUT`
  (only forwarded when set on the command line, mirroring the
  existing `OST_PERSIST_ON_IDLE` pattern).

## [0.1.17] - 2026-06-22 - REV J

`PROTO_HTS` renamed to `PROTO_OSTRICH_Z` (the Z framing and checksums
are a general protocol extension, not Honda-specific). UART GPIO
pins are now build-configurable, enabling Fire 32 A support on
SEL_C (GPIO38) / SEL_D (GPIO39). 32-pin EPROMs (27C010/020/040) are
the new target chip family.

- **Rename**: `PROTO_HTS` → `PROTO_OSTRICH_Z` in `tusb_config.h`,
  `usb_ostrich.c` (20 sites), `Makefile`, `build.sh` (mode name
  `OSTRICH_Z` replaces `HTS`). All "HTS" / "Honda Tuning Suite"
  references in comments updated to "Z-mode" / "Ostrich Z".

- **Configurable UART pins**: `UART_TX_PIN` / `UART_RX_PIN` are now
  `#ifndef`-guarded in `usb_uart.c` with defaults of 26/27 (Fire 28
  SEL_A/SEL_B). Forwarded by `Makefile` `UART_DEFS` when set on the
  make command line. For Fire 32 A: `make UART_TX_PIN=39
  UART_RX_PIN=38`.

- **Fire 32 A UART support**:
  - New pinout: `rust/config/json/fire-32-a-uart.json` (copies
    `fire-32-a.json`, sets `sel: []`, moves `swclk_sel`/`swdio_sel`
    to GPIO 8/9, adds `uart: {tx: 39, rx: 38}` under `alt`).
  - New OneROM configs: `onerom-config/user/fire-32-a-uart-27C010-ostrich-z.json`
    (primary target — Holden ECU/PCM uses 27C010 128K×8),
    `fire-32-a-uart-27C020-ostrich-z.json` (future),
    `fire-32-a-uart-27C040-ostrich-z.json` (future), using
    `rand_128KB.rom` / `rand_256KB.rom` / `rand_512KB.rom` test images
    respectively.

- **No impact on non-UART builds** (NORMAL, HTS, DISABLED, plain
  ALDL_808): same binary as 0.1.16. The 4 ALDL_808 inversion modes
  (NORMAL, TX_INV, RX_INV, TXRX_INV) and the loopback test
  (`aldl_inv_test.py --loopback`) are unchanged.

- **Fire 32 A UART TX/RX pin defaults corrected**:
  - **Bug**: The Fire 32 A `UART_TX_PIN` / `UART_RX_PIN` defaults
    in `usb_uart.c` were inverted relative to the RP2350 family
    function select. FUNCSEL=11 (0x0b) on GPIO38 maps to UART1 TX
    and on GPIO39 maps to UART1 RX, but the defaults had
    `UART_TX_PIN=39`, `UART_RX_PIN=38`. Earlier builds (including
    the 19:18 TunerPro-verified build) overrode the defaults on the
    make command line, so Ostrich CDC operation was unaffected; an
    ALDL_808 ECU link would have had TX and RX crossed.
  - **Fix**: Swapped the `#define` defaults to
    `UART_TX_PIN=38` (SEL_C) and `UART_RX_PIN=39` (SEL_D). The
    function select value `GPIO_CTRL_FUNC_UART = 0x0b` is unchanged.
    Users who were passing the inverted values on the make command
    line should drop `UART_TX_PIN=... UART_RX_PIN=...` (or update
    them to the corrected 38/39).

- **TunerPro RT 5 27C010 write+verify pass**:
  - **Bug**: TunerPro RT 5's Ostrich 2.0 emulation writes a 27C010
    (128 KB) image to R/W banks 6 and 7 of a 512 KB rom_set
    (offsets 0x60000-0x7FFFF) instead of banks 0 and 1
    (0x00000-0x1FFFF). With the OneROM's 27C010 pinout the EPROM
    pins read from 0x00000-0x1FFFF only — so the upload landed
    outside the visible 128 KB window and verify read 0xFF.
  - **Fix**: Remap the bank-6/7 read/write addresses in
    `ost_handle_read` and `ost_begin_write` so bank 6 accesses
    0x00000-0x0FFFF and bank 7 accesses 0x10000-0x1FFFF. The
    B-command tree (`OST_B_R_CMD`) and `OST_FORCE_ROM_SIZE=131072`
    are unchanged — only the address calculation is remapped. The
    27C010 image now lands where the EPROM pins read, and verify
    reads the same bytes back.
  - **Verified**: `picotool load` of the 19:18 build
    (`...27C010-ostrich.bin`, CRC 0x73859815) followed by TunerPro
    RT 5 upload of `images/user/27C010.BIN` completes with write
    100% and verify 100% on the Fire 32 A emulator (GPIO38 TX,
    GPIO39 RX, ALDL_808 at 8192 baud).
  - **Note**: The Z-mode firmware (`...27C010-ostrich-z.bin`) and
    `OST_TRACE_RX`/`OST_TRACE_TX` build switches are unchanged.

## [0.1.16] - 2026-06-22 - REV I+

ALDL_808 inversion modes now use firmware-level XOR instead of the
GPIO pad override.

- **Bug**: The GPIO `INOVER` / `OUTOVER` pad override approach did not
  produce a clean bitwise inversion at 8192 baud for alternating bit
  patterns. Constant patterns (All 0x00, All 0xFF) round-tripped
  correctly, but alternating patterns were corrupted — `0xAA` came
  back as `0x95` (bits 0-5 flipped, bits 6-7 not flipped). All four
  ALDL_808 modes were tested with the physical GPIO26 ↔ GPIO27 loopback
  in `aldl_inv_test.py --loopback`.

- **Fix**: Moved the inversion from the GPIO pad into the bridge code.
  `uart_xform_tx(b)` XORs with 0xFF when `UART_INVERT_TX` is set;
  `uart_xform_rx(b)` XORs with 0xFF when `UART_INVERT_RX` is set. The
  GPIO `INOVER` / `OUTOVER` bits are no longer set — the GPIO ctrl
  register is left at `FUNCSEL=0x0B` (UART1) only. The pad config
  (SLEWFAST/DRIVE/IE/OD) is unchanged for non-inverted modes; for
  inverted modes `SLEWFAST` is cleared (slower edges).

- **Verified**: `python aldl_inv_test.py COM17 8192 <MODE> --loopback`
  passes all 16 checks (980 bytes) for all four ALDL_808 modes:
  NORMAL, TX_INV, RX_INV, TXRX_INV.

- **Impact**: No effect on NORMAL, HTS, DISABLED, or plain ALDL_808
  (no inversion). Only the three `*_Inv` builds pick up the per-byte
  XOR. The XOR is a single instruction per byte and is negligible at
  8192 baud.

## [0.1.15] - 2026-06-22 - REV I

Complete UART mode build matrix — 7 distinct binaries covering all
MODES × SWITCHES combinations.

- **ALDL_808 inversion variants**: Three new builds to cover the four
  combinations of `UART_INVERT_TX` × `UART_INVERT_RX` for the Delco 808
  UART mode (8192 baud). The default `ALDL_808` build is straight-through
  non-inverted (no MAX232 in the signal path). The three new variants
  cover the split-polarity cases:
  - `ALDL_808_TX_Inv`     — TX line inverted, RX straight
  - `ALDL_808_RX_Inv`     — RX line inverted, TX straight
  - `ALDL_808_TXRX_Inv`   — both lines inverted
  Inversion is applied via the RP2350 GPIO `OUTOVER` / `INOVER` bits
  in the GPIO control register, so the UART peripheral sees the
  inverted signal directly — no per-byte XOR transform needed.

- **HTS protocol differentiation**: The `HTS` build now also passes
  `PROTOCOL_MODE=PROTO_HTS` so it includes the 'Z'-prefixed command
  handler and sum-of-bytes checksum. Previously `HTS` was byte-
  identical to `NORMAL` because both used `PROTO_OSTRICH` with the
  same baud. Now `HTS` is ~1.6 KB larger (1648 bytes for the HTS
  parser) and is the only build that uses `PROTO_HTS`. All other
  builds (NORMAL, ALDL_808*) inherit the default `PROTO_OSTRICH`.

- **Makefile filename logic**: `MODE_NAME` is now auto-derived from
  `UART_MODE` plus the `UART_INVERT_TX` / `UART_INVERT_RX` flags.
  When both invert flags are set, the suffix becomes `_TXRX_Inv`
  (concatenated) rather than the redundant `_TX_Inv_RX_Inv`. Output
  files for each of the 7 builds:
    - `usb_emu_system_plugin_NORMAL.bin`
    - `usb_emu_system_plugin_ALDL_808.bin`
    - `usb_emu_system_plugin_ALDL_808_TX_Inv.bin`
    - `usb_emu_system_plugin_ALDL_808_RX_Inv.bin`
    - `usb_emu_system_plugin_ALDL_808_TXRX_Inv.bin`
    - `usb_emu_system_plugin_HTS.bin`
    - `usb_emu_system_plugin_DISABLED.bin`
  A bare-name symlink `usb_emu_system_plugin.bin` always points to
  the most recent build, preserving oneram-config JSON compatibility.

- **build.sh script**: New wrapper that runs `make clean && make` for
  one or all modes, then copies the output to `./output/`. Accepts
  any mode name (or `all`) as a single argument. All 7 outputs land
  in `plugins/system/usb_emu_Switchable_UART/output/`.

- **Verified**: all 7 binaries are byte-distinct (7 unique MD5s,
  27-29 KB each, `DISABLED` smallest at 26 KB since the UART bridge
  is not compiled). No duplicate builds.

## [0.1.14] - 2026-06-21

Change `UART_MODE_NORMAL` default baud rate from 115200 to 38400.
- `UART_BAUD` and `UART_IBRD`/`UART_FBRD` updated in the NORMAL
  else-branch of the baud-rate config in `src/usb_uart.c`.
- Comment at top of section updated to match.
- ALDL_808 (8192) and HTS (38400) branches unchanged.

## [0.1.13] - 2026-06-21

Hardware UART1 bridge — fix wrong base address.
- **Bug**: `UART1_BASE` was set to `0x40070000`, which is
  **UART0**'s base address on RP2350 (per the RP2350 address map in
  the datasheet). GPIO 26/27 are
  routed to UART1, so the init was configuring the wrong
  peripheral. GPIO function was set correctly (FUNCSEL=0x0B
  = UART1) but the UART1 registers were never written to,
  so UART1 stayed disabled (`cr=0x0000`, all loopback tests
  failing with 0 bytes TX and all-0x00 RX).
- **Symptom**: `com_loopback_test.py` returned 0 bytes for
  every test in both directions. `cr` register read back
  as 0x0000 even after the init wrote 0x0301 to it (because
  it was writing to UART0 at `0x40070000`, which is not
  connected to GPIO 26/27).
- **Fix**: `UART1_BASE` changed from `0x40070000` to
  `0x40078000` (the correct RP2350 UART1 base per
  `addressmap.h`).
- **Verified**: `com_loopback_test.py` at 115200 8N1 —
  all 20 checks (1B through 8KB sustained, 16,340 bytes
  total) round-trip cleanly in both directions.
- Pad config also fixed: `setup_gpio()` in stock OneROM
  firmware uses read-modify-write on GPIO_PAD, which
  preserved stray PDE/PUE bits and (worst) set ISO on
  GPIO27, isolating the RX pad. Init now uses plain
  assignment (`=`) for both GPIO_PAD writes to clear
  any stray bits.
- Pad re-apply added to `usb_uart_task()`: 2 stores per
  call, re-asserts the correct pad config in case the
  OneROM firmware's PIO init or anything else clobbers
  it at runtime.

## [0.1.12] - 2026-06-21

ALDL UART bridge TX fix — PIO TX SM was never driving GPIO26.
- **Bug**: `tx->instr = I_SET_PINDIRS(1);` in `usb_uart_init()`
  puts the SM's PC at a random imem location because the
  encoding `0xE081` is not present in any loaded PIO program
  (PIO sets PC = address of the executed instruction in imem;
  if absent, PC goes to an arbitrary slot). The subsequent
  `tx->instr = I_JMP(22)` may or may not land on a valid
  `0x0016` encoding in the serving program. Result: TX SM
  in undefined state, GPIO26 never driven, USB-SERIAL
  receives 0 bytes for every test.
- **Symptom**: `com_loopback_test.py com17 com58` returned
  0 bytes for all frame sizes (1B through 8KB). Single-byte
  Putty echo worked because the human typing rate gave the
  SM time to land in a working state by chance; bulk transfers
  never worked.
- **Diagnostic**: `UART_CDC_SELFTEST=1` firmware (pure
  CDC1→CDC1 echo, bypasses PIO) passes all sizes up to 8KB.
  Proves the CDC/TinyUSB/main-loop path is fine; the bug
  is isolated to the PIO TX init in `usb_uart.c`.
- **Fix**: load a 1-instruction trampoline at slot 21
  (`set pindirs, 1`), then write `tx->instr = I_SET_PINDIRS(1)`
  so the SM lands at slot 21 (executes the trampoline,
  claims GPIO26 as output) and falls through into the TX
  program at slot 22. The RX SM doesn't need this because
  its init only writes `I_JMP(28)` and that encoding happens
  to exist in the serving program.
- **Second fix**: stock OneROM firmware leaves PIO2 out of
  reset (the serving program uses it). Custom builds that
  disable the stock serving program leave PIO2 in reset,
  which freezes all SMs. Added `reset_block()` +
  `unreset_block_wait(RESETS_RESET_PIO2_BITS)` at the start
  of `usb_uart_init()` so the plugin is self-contained.
  New `#define RESETS_RESET_PIO2_BITS (1u << 13)` (not
  provided by the local project headers; value taken from
  `sdrr/include/reg-rp235x.h` during bring-up).
- **Default change**: `UART_INVERT_RX` default for
  `UART_MODE_ALDL_808` changed from 1 to 0. The previous
  default (1) assumed a Delco 808 MAX232 in the signal
  path, which inverts the line. The new default is
  straight-through non-inverted (clean signal path),
  which is the common case for direct USB-SERIAL testing.
  Build with `UART_INVERT_RX=1` to restore the Delco 808
  MAX232 inversion when interfacing with real Delco 808
  hardware.
- New `#define UART_TX_TRAMPOLINE_OFF 21u` (configurable
  if slot 21 is used by the serving program in some build).
- Verified by `check_persistence.py` and Putty echo on
  Delco 808 / 8192 baud.
## [0.1.11] - 2026-06-20

27C512 debug session — clarified 0.1.10 findings.
- HTS host (Honda Tuning Suite) is **32 KB only**. Trace shows 8 ZR
  commands at addresses 0x0080-0x00F0 (bank-header remap, lower
  32K). No commands for the upper 32K (0x8000-0xFFFF). Honda
  Tuning Suite does not support 64 KB images — host software
  limitation, not a firmware issue.
- Bank-header remap for slots 8-15 (upper 32K) is therefore NOT
  needed by HTS. The current remap (slots 0-7, 0x0080-0x00F0)
  is sufficient. No code change.
- The 0.1.10 `check_persistence.py` test at `--rom-size 65536`
  used Z W at addr=0x0000 (non-bank-header path through
  `ost_flat_offset`), which handles the full 16-bit address range.
  This is NOT the same path HTS uses — HTS uses the bank-header
  scheme. The test therefore validated the *non-HTS* Z W path,
  not the HTS bank-header path.
- 64 KB full-chip round-trip confirmed via **CROME** and
  **TunerPro RT** (standard Ostrich protocol, not HTS). CROME
  trace (`crome_27c512_trace.txt`): 289 W commands covering
  0x0000-0xFFCB. The 0.1.9 fix in `ost_write_payload_byte` line
  715 (`ost_persist_mark`) was exercised for all writes. Post-
  power-cycle readback matched source.
- `OST_TRACE_RX` mirror drops bytes during fast HTS streams
  (known limitation, removed in 0.1.6 for RAM budget). For
  debugging HTS read traffic, use a hardware sniffer on the
  Ostrich port or use CROME/TunerPro RT.

## [0.1.10] - 2026-06-20

Verify HTS protocol on 27C512 (64K).
- Tested with the proper HTS build (`make PROTOCOL_MODE=PROTO_HTS
  UART_MODE=UART_MODE_HTS`) and a 27C512 chip type
  (`onerom-config/user/fire-28-a-uart-27C512-hts.json`, 64K test
  image, HTS plugin as system slot).
- Verified end-to-end with `d:\onerom\coding\python\check_persistence.py`
  at `--rom-size 65536`: full 64K uploaded via Z-mode W, readback
  identical to source, power cycle, readback again identical
  (`same=65536  diff=0`).
- The existing 0.1.9 fix handles 64K end-to-end. HTS uses 16-bit
  linear Z-mode W addresses (0x0000-0xFFFF) for the bulk image, so
  the bank-header remap (which only covers slots 0-7, lower 32K) is
  not required for the 27C512 case. No code changes needed.
- The HTS raw-mode entry fix (line 1195 `ost_persist_mark`) is
  untested for 27C512 — Z-mode W was used for this test. If HTS
  switches to raw mode for 27C512 in the wild, that path would
  need a separate test.

## [0.1.9] - 2026-06-20

HTS Z-mode W flash-persistence fix.
- `OST_HTZ_WRITE_STREAM` (Z-mode W block completion) now calls
  `ost_persist_mark(0u, 0u)` to arm the debounced flash auto-commit.
  Previously it only called `ost_persist_touch()`, which bumps the
  debounce timer but does NOT set the dirty flag, so HTS Z-mode W
  uploads landed in RAM and were lost on power cycle.
- HTS raw-mode entry now also calls `ost_persist_mark(0u, 0u)` on
  raw-mode entry, removing the latent dependency on a preceding bare
  W having armed the dirty flag.
- Added per-byte `ost_persist_touch()` in the Z-mode W data phase so
  the 1500 ms commit debounce is pushed back for the full block
  (was previously only on the final byte; a long block could
  otherwise commit mid-stream and stall USB).
- All three changes are HTS-only (inside `#if PROTOCOL_MODE ==
  PROTO_HTS`); Ostrich/TunerPro path is untouched.
- Verified end-to-end on 27C256 (32K) with
  `d:\onerom\coding\python\check_persistence.py`: upload via Z-mode
  W, readback identical to source, power cycle, readback again
  identical to source.

## [0.1.8] - 2026-06-19

Z-mode W streaming implementation (HTS bulk ROM upload support).
- Added OST_HTZ_WRITE_STREAM state for Z-mode W streaming: Z W count
  addr_hi addr_lo [count*256 raw bytes] → single 'O' at completion.
  This is the primary upload mechanism used by Honda Tuning Suite.
- Modified OST_HTZ_SYNC handler: 'W' now enters OST_HTZ_WRITE_STREAM
  instead of OST_WRITE_PARAMS, which was misinterpreting the streaming
  header as a standard W command.
- Streaming accumulates 3-byte header (count, addr_hi, addr_lo),
  calculates total = count * 256, writes raw bytes sequentially to ROM.
- Added htz_stream_remaining field to ost_ctx_t for streaming byte count.
- Address decoding: uses ost_decode_addr (big-endian) with ost_flat_offset
  for ROM address mapping. No 0x8000 subtraction needed since HTS sends
  pre-mapped addresses (0x0080-0x00E0) to our firmware.
- Documented Z-mode R protocol (Z R count addr_hi addr_lo cksum →
  count*256 bytes + checksum) for future implementation.
- Updated file header comments with complete HTS protocol documentation.

## [0.1.7] - 2026-06-19

HTS upload fix: threshold-based raw mode detection + bank header offset fix.
- Fixed bank header W rewrite offset: was `slot * 0x1000 + data_idx`,
  now correctly `slot * 0x1000 + 0x80 + data_idx`. Bank headers at
  0x0080-0x00F0 now land at the right slot addresses (0x0080, 0x1080, etc.).
- Non-bank-header Ws (e.g. 65-byte config writes) fall through to flat-offset
  write, preserving TunerPro compatibility.
- Raw mode entry moved from OST_POST_W_CHECK to OST_IDLE with a consecutive-
  stray threshold (>=2 non-command bytes). Previously every W completion
  entered raw mode immediately (16 entries for 17 Ws), each waiting 500ms
  idle timeout, totalling 8+ seconds of dead time that caused HTS timeouts.
  Now only the actual raw binary start (multiple consecutive non-command bytes)
  triggers raw mode.
- POST_W_CHECK saves the first stray byte in pending_raw_byte; when the
  threshold fires in IDLE the saved byte is written to ROM[0] and the
  triggering byte to ROM[1], so no data is lost.
- Added raw mode OOB exit: when raw_offset exceeds ROM size, raw mode exits
  and the byte is reprocessed as a command, allowing post-upload FF queries.
- Timestamp-based raw_idle timeout (board_millis(), 500ms gap) replaces
  counter-based approach for reliable idle detection across varying task
  call rates.
- Diagnostic instrumentation: OST_DBG_FIRSTW=1 appends AA55 first-W block,
  BB66 write-log (8 wlog entries) + capture buffer, and CC77 HTS diagnostics
  (post_w_entered, raw_entered, first byte, was_cmd) to the FF reply.

## [0.1.6] - 2026-06-19

HTS raw binary upload mode + false W investigation.
- HTS sends config W commands (bank register setup) then the full ROM image
  as raw bytes with no command framing. Added raw_mode: when a non-command
  byte enters IDLE after w_completed_any, enter raw mode writing bytes
  sequentially to ROM starting at write_offset.
- Raw mode uses counter-based idle timeout (raw_idle=10, decremented per
  task call) to exit after ~10ms gap, allowing post-upload FF queries.
- `ost_persist_touch()` called during raw writes to prevent flash commit
  mid-upload.
- **Known limitation**: if the first raw byte is 0x57 ('W'), the parser
  enters OST_WRITE_PARAMS (a "false W"). ost_begin_write() clobbers
  write_offset to a wrong address, corrupting the upload. The non-'W'
  first-byte case works correctly. A fix distinguishing false Ws from
  real config Ws is needed.
- Diagnostic instrumentation: OST_DBG_FIRSTW=1 appends a write-log (up to
  11 W command headers) and post-write capture buffer to the FF reply.
  Reduced OST_DBG_CAP_LEN from 64 to 56 and OST_DBG_WLOG_MAX from 12
  to 11 for RAM budget. Removed OST_TRACE_RX per-byte mirroring.
- Removed raw_start/raw_skip/raw_captured fields (saved ~8 bytes RAM)
  after determining they cannot reliably distinguish false Ws from real
  config Ws at stray handler time.

## [0.1.5] - 2026-06-19

Fix HTS detection: add BRR and S command handlers (PROTO_HTS only).
- HTS sends bare `BRR` (42 52 52 E6) and `S` (53 param cksum) commands
  during connect. Without handlers these were stray bytes and HTS failed
  to detect the Ostrich.
- `BRR` replies `0x00` then swallows trailing checksum (matches working
  Moates firmware). `BB` remains silent (no reply).
- `S` swallows param + checksum silently (no reply).
- All BRR/S code is guarded by `#if PROTOCOL_MODE == PROTO_HTS`; the
  default TunerPro build (`PROTO_OSTRICH`) is completely untouched.
- To undo: build without `PROTOCOL_MODE=PROTO_HTS` (default is
  `PROTO_OSTRICH`), or revert this entry and the BRR/S changes in
  `usb_ostrich.c` (states OST_B_2ND through OST_S_CKSUM and their
  case handlers in `ost_feed_once`).

## [0.1.4] - 2026-06-19

Add Honda Tuning Suite (HTS) protocol support via PROTOCOL_MODE build switch.
- `PROTOCOL_MODE=PROTO_OSTRICH` (default): unchanged Ostrich behaviour
- `PROTOCOL_MODE=PROTO_HTS`: 'Z'-prefixed Ostrich commands with checksums
  on CDC 0, plus 38400-baud ECU datalogging on CDC 1 (GPIO26/27)
- Build with `make PROTOCOL_MODE=PROTO_HTS` to compile the HTS variant
- Modes are mutually exclusive at compile time; zero impact on default build

## [0.1.3] - 2026-06-08

First-block-drop diagnostic counters, persistence debounce improvements

## [0.1.2] - 2026-04-10

Live ROM image improvements, persistence guard, dirty-sector compare-skip

## [0.1.1] - 2026-03-26

Fix live ROM image peek/poke for 28 pin chips

## [0.1.0] - 2026-03-25

First release