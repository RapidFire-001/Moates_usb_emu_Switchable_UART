# Count non-zero printable chars that are actual hex data
$lines = Get-Content 'D:\OneROM\CODING\python\trace_COM50_20260619-100233.txt'
$nonZeroLines = @()
foreach ($line in $lines) {
    if ($line -match '^\[' -and $line -notmatch '^(\s*00\s*)+\|') {
        $nonZeroLines += $line
    }
}
Write-Output "Total lines: $($lines.Count)"
Write-Output "Non-all-zero command lines: $($nonZeroLines.Count)"
foreach ($l in $nonZeroLines) {
    Write-Output $l
}
