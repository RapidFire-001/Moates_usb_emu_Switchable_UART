#!/usr/bin/env bash
#
# build.sh - build the usb_emu_system_plugin for one or all UART modes
#
# Usage:
#   ./build.sh NORMAL                # 38400 baud, PROTO_OSTRICH (default)
#   ./build.sh ALDL_808              # 8192 baud, no inversion, PROTO_OSTRICH
#   ./build.sh ALDL_808_TX_Inv       # 8192 baud, TX line inverted, PROTO_OSTRICH
#   ./build.sh ALDL_808_RX_Inv       # 8192 baud, RX line inverted, PROTO_OSTRICH
#   ./build.sh ALDL_808_TXRX_Inv     # 8192 baud, TX and RX inverted, PROTO_OSTRICH
#   ./build.sh OSTRICH_Z             # 38400 baud, PROTO_OSTRICH_Z (Z-prefixed + checksum)
#   ./build.sh DISABLED              # no UART bridge
#   ./build.sh all                   # build all seven modes sequentially
#
# Each mode is built with `make clean && make UART_MODE=... [UART_INVERT_*=1]
# [PROTOCOL_MODE=...]`, then the output .bin is copied to ./output/ before the
# next mode starts, so all outputs are preserved.

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BUILDS_DIR="${SCRIPT_DIR}/output"

MODES=(NORMAL ALDL_808 ALDL_808_TX_Inv ALDL_808_RX_Inv ALDL_808_TXRX_Inv OSTRICH_Z DISABLED)

build_mode() {
    local mode="$1"
    local make_args=()
    local makefile_stem="$mode"   # .bin filename stem as Makefile produces it
    local out_name="$mode"         # .bin filename stem as exposed in output/

    case "$mode" in
        NORMAL)
            make_args=()
            makefile_stem="NORMAL"
            ;;
        ALDL_808)
            make_args=("UART_MODE=UART_MODE_ALDL_808")
            makefile_stem="ALDL_808"
            ;;
        ALDL_808_TX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_TX=1")
            makefile_stem="ALDL_808_TX_Inv"
            ;;
        ALDL_808_RX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_RX=1")
            makefile_stem="ALDL_808_RX_Inv"
            ;;
        ALDL_808_TXRX_Inv)
            make_args=("UART_MODE=UART_MODE_ALDL_808" "UART_INVERT_TX=1" "UART_INVERT_RX=1")
            makefile_stem="ALDL_808_TXRX_Inv"
            ;;
        OSTRICH_Z)
            # Makefile derives the output name from UART_MODE (HTS).
            # Public-facing name is OSTRICH_Z for clarity.
            make_args=("UART_MODE=UART_MODE_HTS" "PROTOCOL_MODE=PROTO_OSTRICH_Z")
            makefile_stem="HTS"
            out_name="OSTRICH_Z"
            ;;
        DISABLED)
            make_args=("UART_MODE=UART_MODE_DISABLED")
            makefile_stem="DISABLED"
            ;;
        *)
            echo "Unknown mode: $mode" >&2
            return 1
            ;;
    esac

    echo "=========================================="
    echo "Building mode: $mode"
    if [ ${#make_args[@]} -gt 0 ]; then
        echo "  make args: ${make_args[*]}"
    fi
    echo "=========================================="
    cd "$SCRIPT_DIR"
    make clean >/dev/null
    make all "${make_args[@]}"

    local bin_file="${SCRIPT_DIR}/build/usb_emu_system_plugin_${makefile_stem}.bin"
    if [ ! -f "$bin_file" ]; then
        echo "ERROR: expected output not found: $bin_file" >&2
        return 1
    fi

    mkdir -p "$BUILDS_DIR"
    cp "$bin_file" "${BUILDS_DIR}/usb_emu_system_plugin_${out_name}.bin"
    echo "Copied to: ${BUILDS_DIR}/usb_emu_system_plugin_${out_name}.bin"
}

usage() {
    echo "Usage: $0 [MODE|all]"
    echo ""
    echo "Modes:"
    echo "  NORMAL              38400 baud, PROTO_OSTRICH (default)"
    echo "  ALDL_808            8192 baud, no inversion, PROTO_OSTRICH"
    echo "  ALDL_808_TX_Inv     8192 baud, TX line inverted, PROTO_OSTRICH"
    echo "  ALDL_808_RX_Inv     8192 baud, RX line inverted, PROTO_OSTRICH"
    echo "  ALDL_808_TXRX_Inv   8192 baud, TX and RX inverted, PROTO_OSTRICH"
    echo "  OSTRICH_Z           38400 baud, PROTO_OSTRICH_Z (Z-prefixed + checksum)"
    echo "  DISABLED            no UART bridge"
    echo "  all                 build all seven modes"
    exit 1
}

if [ $# -eq 0 ]; then
    usage
fi

case "$1" in
    -h|--help|help)
        usage
        ;;
    all)
        for m in "${MODES[@]}"; do
            build_mode "$m"
        done
        echo ""
        echo "All modes built. Outputs in $BUILDS_DIR:"
        ls -la "$BUILDS_DIR"
        ;;
    *)
        # Check it's a valid mode
        valid=0
        for m in "${MODES[@]}"; do
            if [ "$1" = "$m" ]; then
                valid=1
                break
            fi
        done
        if [ $valid -eq 0 ]; then
            echo "Unknown mode: $1" >&2
            usage
        fi
        build_mode "$1"
        ;;
esac
