# One ROM `usb_emu` System Plugin — Build Options Reference

Everything you can set at compile time, what it does, and the exact `make`
invocations. Built from the Debian box; flash the resulting `.bin` to the One
ROM; the Python probe runs on the Windows machine.

Build directory (example):
`/mnt/md0/Share/C64/Git/one-rom/plugins/system/usb_emu_32Kb_Switchable_UART`

---

## TL;DR — the commands you actually use

```bash
# Always clean when changing any UART_* switch (defines don't force a rebuild on their own)
make clean && make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=1     # ALDL, RX inverted
make clean && make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=0     # ALDL, RX non-inverted
make clean && make all UART_MODE=UART_MODE_NORMAL                        # 115200 8N1, for bench/loopback
make clean && make all UART_MODE=UART_MODE_DISABLED                      # no 2nd CDC, UART off

# Verify a switch actually reaches the compiler (dry run):
make clean >/dev/null 2>&1; make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=0 -n | grep -- -DUART
#   -> must print:  -DUART_MODE=UART_MODE_ALDL_808 -DUART_INVERT_RX=0
```

> IMPORTANT: the Makefile only forwards a switch when you set it on the command
> line. If you DON'T pass `UART_MODE=...`, the build uses the default baked into
> `include/tusb_config.h` (which is `UART_MODE_NORMAL`). Earlier in this project
> the Makefile didn't forward these at all — if `grep -n UART_DEFS Makefile`
> returns nothing, you're on the OLD Makefile and the switches are being
> ignored. Use the updated Makefile from the Rev F1 bundle.

---

## 1. `UART_MODE` — which UART profile (and whether the 2nd CDC exists)

Single source of truth in `include/tusb_config.h`; drives both the USB
descriptors and `usb_uart.c`. Default if unset: `UART_MODE_NORMAL`.

| Value | Baud | TX invert | RX invert | 2nd CDC port | Use for |
|---|---|---|---|---|---|
| `UART_MODE_NORMAL`   | 115200 | 0 | 0 | yes | Bench/loopback testing in a normal terminal |
| `UART_MODE_ALDL_808` | 8192   | 0 | 1 | yes | GM/Holden Delco 808 ALDL (default inverts shown; override below) |
| `UART_MODE_DISABLED` | —      | — | — | **no** | Hide the UART; device shows ONE CDC (Ostrich) only |

```bash
make clean && make all UART_MODE=UART_MODE_NORMAL
make clean && make all UART_MODE=UART_MODE_ALDL_808
make clean && make all UART_MODE=UART_MODE_DISABLED
```

Notes:
- `NORMAL` and `ALDL_808` both enumerate two CDC ports: "One ROM Serial"
  (Ostrich, instance 0) and "One ROM CDC Trace" (the UART, instance 1).
  Point the probe / terminal at instance 1.
- `DISABLED` hides the 2nd CDC entirely (init/task become stubs); only the
  Ostrich port appears. Use it if you want the plugin without the UART.
- The old `UART_MODE_ALDL` (both lines inverted, for tapping the *raw* ALDL
  line) was removed. `ALDL_808` is the post-MAX232 / split-polarity profile.

---

## 2. `UART_INVERT_TX` / `UART_INVERT_RX` — per-direction line polarity

Override the inversion independently per direction. Each applies an inversion
in the RP2350 pad (TX uses OUTOVER, RX uses INOVER). If you don't set them,
they take the mode's defaults (see table above).

```bash
# Force RX non-inverted (overrides the ALDL_808 default of RX=1):
make clean && make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=0

# Set both explicitly:
make clean && make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_TX=0 UART_INVERT_RX=1
```

### How to choose the values — it is a 2-build experiment, not a guess
You rarely know the true line polarity up front (depends on the ECU, the tap
point, and whether any buffer/inverter board is in the path). So:

1. Build one way, flash, probe.
2. If the result is wrong, flip `UART_INVERT_RX` and rebuild.

Reading the probe result:
- **Continuous `0x00` flood (hundreds of bytes/poll, all zero)** = the line's
  idle is being seen as LOW (start-bit/space). Polarity is inverted from what
  it should be -> **flip `UART_INVERT_RX`**.
- **Totally empty (0 bytes/poll)** = the line idles HIGH (mark/rest), receiver
  is correctly silent on idle, but no real frames are arriving. Polarity for
  idle is fine; the problem is upstream (no signal / ECU not answering).
- **Varied, structured, repeating frames** = correct. Done.

### Inversion bookkeeping when a hardware buffer/inverter is in the path
Each inverting gate (e.g. SN74LVC1T14) adds ONE inversion. Total inversions in
a path must be **even** for the data to arrive as sent.

Total = `UART_INVERT_TX` + (TX gates) + (RX gates) + `UART_INVERT_RX` + (line polarity)

- **Bare GPIO26<->27 loopback (no board):** for a clean echo, `UART_INVERT_TX`
  must **equal** `UART_INVERT_RX` (both 0 or both 1). Mismatched = mangled echo.
- **Through ONE inverting RX gate (e.g. U1 only):** one inversion in the path,
  so for loopback the inverts must be **unequal** (e.g. TX=0, RX=1).
- **Through two inverting gates (U1+U2 loopback):** two inversions = even, so
  inverts must **match** again (both 0 or both 1).

---

## 3. `UART_CDC_SELFTEST` — CDC loopback diagnostic (bypasses the PIO)

When `=1`, `usb_uart_task()` becomes a pure CDC1->CDC1 echo that does NOT touch
the PIO. Type in the CDC Trace port; if it echoes, USB/CDC/enumeration/task are
all good and any UART problem is in the PIO or wiring. Default `0`.

```bash
make clean && make all UART_CDC_SELFTEST=1
```

Use it to split "is the USB/CDC side alive?" from "is the PIO UART alive?".
(It's guarded and compiles to nothing when `0`, so it never affects a normal
build.)

---

## 4. `PLUGIN_CRC_CHECK` — plugin image integrity check

Default `1` (ON). Appends a CRC32 trailer to the `.bin` at build time;
`usb_main.c` recomputes at runtime and, on mismatch, blinks the status LED
(GPIO29) from the main loop. It NEVER gates ROM serving. Requires `python3` in
PATH at build time.

```bash
make clean && make all PLUGIN_CRC_CHECK=1     # default, ON
make clean && make all PLUGIN_CRC_CHECK=0     # OFF (no trailer, no runtime check)
```

---

## 5. `OST_CDC_RX_FS` — CDC RX FIFO size (Fire 32 A tuning)

Default `64` (bytes, per CDC instance). The CDC RX FIFO must be at least the
USB FS bulk max packet size (64 B) or host bulk OUTs truncate and data is
silently lost. The TX FIFO and vendor FIFOs are fixed at 32 B each.

On Fire 32 A the plugin DATA_LIMIT is 2 KB and the persist code adds
significant overhead. The FIFOs are sized to leave ~200 B of headroom with
persist on. If a future build needs more headroom, drop to 32 B per CDC TX
and vendor (RX is locked at 64 B).

```bash
make clean && make all OST_CDC_RX_FS=64      # default, USB FS bulk max packet
make clean && make all OST_CDC_RX_FS=128     # larger, for high-throughput hosts
# 32 B is UNSAFE — host bulk OUTs truncate. Debug only.
```

This knob is irrelevant on Fire 28 (one CDC, no persist, plenty of headroom).

---

## 6. `OST_DEBUG_LAYOUT` — boot-time PIO layout dump

Default `0` (OFF). When set, the first Ostrich reply is prepended with a
human-readable dump of the PIO pin layout (valid, numbits, romsize, chip, rsi,
addr[], data[], cs1/cs2, rt). Adds ~192 B of `.bss` and ~250 B of code.
Useful when the COM port can't be opened until after boot (the dump is
prepended to the first Ostrich read so it appears in any host capture).

```bash
make clean && make all OST_DEBUG_LAYOUT=1     # enable layout dump
```

Used historically to diagnose the Fire 32 A bit-reverse bug
(`app_logical_addr_to_offset` in `usb_rom.c`). Off in production by default.

---

## 7. Persistence (set in source, not a make switch)

`OST_PERSIST_ON_IDLE` in `usb_ostrich.c` (default `1`, ON): debounced flash
auto-commit of Ostrich writes after ~1500 ms idle. To disable, build with
`-DOST_PERSIST_ON_IDLE=0` (add it to CFLAGS) or change the source default.
`FLASH_PROTECTED_END` must be the XIP value `0x10020000`.

Without persist, every power cycle drops the uploaded image back to the cold
flash preload — the Ostrich emulation is useless on the bench without it.
The persist code (chunked 4 KB commit, skip-if-unchanged, function pointer
indirection) is the reason the FIFO sizes had to be shrunk to fit the
Fire 32 A 2 KB plugin DATA_LIMIT.

---

## 8. `DISABLED` mode — actually single-CDC now

The `UART_MODE_DISABLED` build is meant to enumerate with ONE CDC (the
Ostrich channel) only, with no UART bridge code compiled in. Pre-0.1.18 this
was broken: a leftover `#if PROTOCOL_MODE == PROTO_HTS` override in
`tusb_config.h` referred to a symbol that was renamed to `PROTO_OSTRICH_Z`.
The undefined `PROTO_HTS` evaluated to `0` in the `#if`, so `0 == 0` was
always true and the override forced `UART_CDC_PRESENT = 1` and
`CFG_TUD_CDC = 2` for every build, including DISABLED.

The fix (0.1.18) was to remove the dead override. The remaining
`UART_CDC_PRESENT = (UART_MODE != UART_MODE_DISABLED)` is the single source
of truth. Effect on Fire 32 A (persist on, layout debug off):

| Mode | `.bss` | `_cdcd_itf` | CDC count | `.bin` |
|---|---|---|---|---|
| NORMAL / ALDL_808 / ALDL_808_*_Inv | 1672 B | 360 B | 2 | 27708 B |
| **DISABLED** | **1408 B** | **180 B** | **1** | **26840 B** |

The 5 non-DISABLED modes are byte-identical to before — the fix is
DISABLED-only.

---

## Combining switches

Switches are independent; combine freely. Examples:

```bash
# ALDL, RX non-inverted, CRC off (faster iterate), default persistence:
make clean && make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=0 PLUGIN_CRC_CHECK=0

# Normal 115200 for a clean terminal loopback, self-test echo on:
make clean && make all UART_MODE=UART_MODE_NORMAL UART_CDC_SELFTEST=1

# UART completely disabled (single CDC), CRC on:
make clean && make all UART_MODE=UART_MODE_DISABLED
```

---

## Verifying / troubleshooting the build itself

```bash
# 1. Is the updated (forwarding) Makefile in place?
grep -n UART_DEFS Makefile
#    -> several UART_DEFS lines = good; nothing = OLD Makefile, switches ignored.

# 2. Do the switches reach the compiler? (dry run, clean first so it prints)
make clean >/dev/null 2>&1; make all UART_MODE=UART_MODE_ALDL_808 UART_INVERT_RX=1 -n | grep -- -DUART
#    -> must show -DUART_MODE=... -DUART_INVERT_RX=1 on each compile line.

# 3. What default am I building if I pass NO switches?
grep -n "define UART_MODE" include/tusb_config.h
#    -> the line `#define UART_MODE  UART_MODE_xxx` is the fallback default.

# 4. Are the per-direction invert overrides present in the source?
grep -n "ifndef UART_INVERT_RX" src/usb_uart.c
#    -> must return a line, or -DUART_INVERT_RX= will cause a redefinition error.
```

Common gotchas learned the hard way:
- **A switch did nothing** -> you're on the old Makefile (no `UART_DEFS`), or you
  didn't `make clean` so the object wasn't recompiled. Always `make clean` when
  changing a `-D`.
- **`-n | grep` printed nothing** -> the build was already up to date so the dry
  run had no compile lines. Run `make clean` first, then the `-n` dry run.
- **RX=0 and RX=1 give identical results** -> the switch isn't being applied
  (old Makefile / no clean). Verify with the dry-run grep above before drawing
  any conclusion about polarity.

---

## Bench test recipes (no ECU)

```bash
# A) Prove the One ROM itself (CDC + PIO TX + PIO RX), bare GPIO26<->27 jumper:
make clean && make all UART_MODE=UART_MODE_NORMAL
#   terminal @115200 on the CDC Trace port, local echo OFF, type -> clean echo.
#   (Or ALDL_808 with matched inverts + aldl_probe2.py -> echoes f4 57 01 00.)

# B) Prove just the USB/CDC side (no PIO):
make clean && make all UART_CDC_SELFTEST=1
#   type in CDC Trace port -> echoes = USB/CDC/task all good.

# C) Prove a buffer/inverter board in loopback (ECU pins jumpered together):
#   count the gates' inversions and set TX/RX inverts so the total is EVEN,
#   then expect a clean f4 57 01 00 echo via aldl_probe2.py.
```

## The probe (Windows side)

```bash
python aldl_probe2.py COM<N>            # sends F4 57 01 00 B4 + disable-chatter, strips echo
python aldl_probe2.py COM<N> --passive  # listen only: does the ECU free-run?
```
Win condition for a live ECU: varied, repeating ~60-byte frames (the OSE $12P
mode-1 packet is ~60 bytes incl. header + checksum).
