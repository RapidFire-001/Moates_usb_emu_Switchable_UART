// Copyright (C) 2026
//
// MIT License
//
// One ROM USB system plugin - UART <-> CDC bridge
//
// Serial bridge between the 2nd CDC ("One ROM CDC Trace", index 1) and RP2350
// HW UART1 (Fire 32 A: GPIO38 TX / GPIO39 RX, FUNCSEL 0x0B). CDC 0 ("One ROM
// Serial") stays the Ostrich channel. UART1_BASE=0x40078000 (0x40070000=UART0).
// Usage: usb_uart_init() once after tusb_init(); usb_uart_task() each main-loop
// after tud_task(). tud_cdc_rx_cb() must NOT drain the CDC RX FIFO (would steal
// PC->ECU bytes before the bridge sees them).

#ifndef USB_UART_H
#define USB_UART_H

// Initialise the UART1 bridge. Call after tusb_init() returns.
void usb_uart_init(void);

// Pump bytes between the CDC interface and the UART. Call once per main loop
// iteration, after tud_task().
void usb_uart_task(void);

#endif // USB_UART_H
