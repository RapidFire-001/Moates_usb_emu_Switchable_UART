// Copyright (C) 2026 — MIT License
//
// One ROM USB system plugin: Data Tracing (DT) header.
// Enabled with DT=1 build flag. For 27C256/27C512 only (28-pin, <=64KB).

#ifndef USB_DT_H_
#define USB_DT_H_

#include <stdint.h>
#include <stdbool.h>
#include "plugin.h"

// No-op. Real init happens in usb_dt_init_with_lookup().
void usb_dt_init(void);

// Resolve ORA API functions, validate chip type, start address monitor.
void usb_dt_init_with_lookup(ora_lookup_fn_t ora_lookup_fn);

// Main loop task. Drains the ring buffer and counts captures.
void usb_dt_task(void);

// Retrieve the next captured logical address. Returns false if ring is empty.
bool usb_dt_get_capture(uint32_t *logical_addr_out);

// Total addresses captured since init.
uint32_t usb_dt_get_capture_count(void);

#endif // USB_DT_H_
