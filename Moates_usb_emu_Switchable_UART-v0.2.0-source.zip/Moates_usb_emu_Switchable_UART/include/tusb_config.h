// Copyright (C) 2026 Piers Finlayson <piers@piers.rocks>
//
// MIT License

// tinyusb configuration header for One ROM's USB system plugin
//
// REV J0.2: PROTOCOL_MODE build switch (Ostrich / Ostrich Z). OST_CDC_RX_FS is
// a build knob (default 64). DT flag enables address bus monitoring.

// Based on a tinyusb example.

/*
 * The MIT License (MIT)
 *
 * Copyright (c) 2019 Ha Thach (tinyusb.org)
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 */

#ifndef TUSB_CONFIG_H_
#define TUSB_CONFIG_H_

#ifdef __cplusplus
 extern "C" {
#endif

// One ROM specific configuration
#define __not_in_flash(x)
#define CFG_TUD_TASK_QUEUE_SZ     4
// Protocol mode:
//   PROTO_OSTRICH   : bare Ostrich serial for TunerPro RT (no 'Z', no checksums).
//   PROTO_OSTRICH_Z : adds 'Z'-prefixed commands + sum checksums + ZW/ZR bulk
//                     streaming. Requires UART_MODE_HTS for datalogging.
#define PROTO_OSTRICH    0
#define PROTO_OSTRICH_Z  1
#ifndef PROTOCOL_MODE
#define PROTOCOL_MODE    PROTO_OSTRICH
#endif

// Second CDC ("One ROM CDC Trace") mode. Single source of truth for descriptors
// and usb_uart.c; override with -DUART_MODE=UART_MODE_xxx.
//   NORMAL   : CDC1, non-inverted 115200 8N1
//   ALDL_808 : CDC1, Delco 808 post-MAX232 tap — split polarity (TX non-inv,
//              RX inv), 8192
//   HTS      : CDC1, Honda datalogging 38400 8N1
//   DISABLED : CDC1 hidden — one CDC only, bridge not built
//   DT=1     : build flag — enables PIO address bus monitoring (any UART_MODE)
#define UART_MODE_NORMAL    0
#define UART_MODE_DISABLED  2
#define UART_MODE_ALDL_808  3
#define UART_MODE_HTS       4
#ifndef UART_MODE
#define UART_MODE           UART_MODE_NORMAL
#endif
#define UART_CDC_PRESENT    (UART_MODE != UART_MODE_DISABLED)

// Endpoint budget: vendor + CDC0 use 0..3; a second CDC adds 4..5, so it needs
// 6 (a single-CDC build needs only 4 - which is what made a 2nd CDC impossible).
#if UART_CDC_PRESENT
#define CFG_TUD_ENDPOINT_MAX      6
#else
#define CFG_TUD_ENDPOINT_MAX      4
#endif
#define USB_MAX_ENDPOINTS         CFG_TUD_ENDPOINT_MAX

// Board Specific Configuration

// RHPort number used for device can be defined by board.mk, default to port 0
#ifndef BOARD_TUD_RHPORT
#define BOARD_TUD_RHPORT      0
#endif

// RHPort max operational speed can defined by board.mk
#ifndef BOARD_TUD_MAX_SPEED
#define BOARD_TUD_MAX_SPEED   OPT_MODE_DEFAULT_SPEED
#endif

// Common Configuration

// defined by compiler flags for flexibility
#define CFG_TUSB_MCU   OPT_MCU_RP2040
#ifndef CFG_TUSB_MCU
#error CFG_TUSB_MCU must be defined
#endif

#ifndef CFG_TUSB_OS
#define CFG_TUSB_OS           OPT_OS_NONE
#endif

#ifndef CFG_TUSB_DEBUG
#define CFG_TUSB_DEBUG        0
#endif

// Enable Device stack
#define CFG_TUD_ENABLED       1

// Default is max speed that hardware controller could support with on-chip PHY
#define CFG_TUD_MAX_SPEED     BOARD_TUD_MAX_SPEED

/* USB DMA on some MCUs can only access a specific SRAM region with restriction on alignment.
 * Tinyusb use follows macros to declare transferring memory so that they can be put
 * into those specific section.
 * e.g
 * - CFG_TUSB_MEM SECTION : __attribute__ (( section(".usb_ram") ))
 * - CFG_TUSB_MEM_ALIGN   : __attribute__ ((aligned(4)))
 */
#ifndef CFG_TUSB_MEM_SECTION
#define CFG_TUSB_MEM_SECTION
#endif

#ifndef CFG_TUSB_MEM_ALIGN
#define CFG_TUSB_MEM_ALIGN        __attribute__ ((aligned(4)))
#endif

// DEVICE CONFIGURATION

#ifndef CFG_TUD_ENDPOINT0_SIZE
#define CFG_TUD_ENDPOINT0_SIZE    64
#endif

//------------- CLASS -------------//
// CDC ports: index 0 "One ROM Serial" (Ostrich-compatible serial); index 1
// "One ROM CDC Trace" (PIO UART passthrough) only when UART_CDC_PRESENT.
#if UART_CDC_PRESENT
#define CFG_TUD_CDC               2
#else
#define CFG_TUD_CDC               1
#endif
#define CFG_TUD_MSC               0
#define CFG_TUD_HID               0
#define CFG_TUD_MIDI              0
#define CFG_TUD_VENDOR            1

// CDC FIFO size, PER INSTANCE — this build has two CDCs (Ostrich + Trace) so
// every byte costs 2x SRAM. Sized to fit the 2 KB plugin DATA_LIMIT:
//   CDC RX = 64 B (MUST be >= 64 = USB FS bulk max packet, or host OUTs truncate)
//   CDC TX = 32 B; Vendor = 32 B/dir
// NAK backpressure handles overruns; raise via OST_CDC_RX_FS=128. Below 64 is
// unsafe (truncates the 64-byte FS bulk packet).
#ifndef OST_CDC_RX_FS
#define OST_CDC_RX_FS             64
#endif
#define CFG_TUD_CDC_RX_BUFSIZE    (TUD_OPT_HIGH_SPEED ? 512 : OST_CDC_RX_FS)
#define CFG_TUD_CDC_TX_BUFSIZE    (TUD_OPT_HIGH_SPEED ? 512 : 32)

// Vendor FIFO size of TX and RX
// If zero: vendor endpoints will not be buffered
#define CFG_TUD_VENDOR_RX_BUFSIZE (TUD_OPT_HIGH_SPEED ? 512 : 32)
#define CFG_TUD_VENDOR_TX_BUFSIZE (TUD_OPT_HIGH_SPEED ? 512 : 32)


#ifdef __cplusplus
 }
#endif

#endif /* TUSB_CONFIG_H_ */
