/*
 * usb_ostrich.h - Ostrich-compatible serial protocol on CDC interface 0.
 *
 * Makes "One ROM Serial" (CDC 0) present as an Ostrich EPROM emulator for
 * TunerPro RT 5 and other Ostrich tools. Rules (see usb_ostrich.c):
 *   1. All parsing runs in usb_ostrich_task() (main loop), never in
 *      tud_cdc_rx_cb (IRQ) - a bank write in IRQ can bkpt-assert on big uploads.
 *   2. Every access is clamped to the active ROM size: OOB write dropped,
 *      OOB read 0xFF, never faults.
 * CDC 0 is already enumerated (dual-CDC build); leave CDC 1 (UART bridge) alone.
 */

#ifndef USB_OSTRICH_H
#define USB_OSTRICH_H

#include <stdint.h>
#include <stdbool.h>

/* The CDC interface this emulation runs on. CDC 0 = "One ROM Serial". */
#define OST_CDC_ITF              0

/* Lifecycle - call from the plugin glue. */

/* One-time init. Call once at startup (alongside usb_uart_init()). */
void usb_ostrich_init(void);

/* Pump: call every main-loop iteration. Drains CDC 0 RX, parses/executes
 * commands, emits responses. Task context, not IRQ. */
void usb_ostrich_task(void);

/* Integration hooks - implement these (reference bindings at usb_ostrich.c
 * bottom). Only coupling to the One ROM memory engine. */

/* Active ROM image size in bytes; bounds every access. Bind to
 * app_get_active_rom_size(). */
uint32_t ostrich_active_rom_size(void);

/* Read/write one byte of the logical ROM image at a flat offset. Bind to the
 * One ROM logical accessors (base 0x90000000). Always called with
 * offset < ostrich_active_rom_size(), so no bounds check needed. */
uint8_t  ostrich_rom_read_byte(uint32_t offset);
void     ostrich_rom_write_byte(uint32_t offset, uint8_t value);

/* Optional: point the ECU-visible window at emulation bank `bank` (0..8).
 * On hardware without switchable windows this can be a no-op. Never trap. */
void     ostrich_set_emulation_window(uint8_t bank);

#endif /* USB_OSTRICH_H */
